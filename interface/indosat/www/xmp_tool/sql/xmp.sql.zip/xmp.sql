-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 15, 2012 at 01:42 PM
-- Server version: 5.5.10
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `xmp`
--

-- --------------------------------------------------------

--
-- Table structure for table `adn`
--

CREATE TABLE IF NOT EXISTS `adn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  `description` varchar(128) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `adn`
--

INSERT INTO `adn` (`id`, `name`, `description`, `date_created`, `date_modified`, `status`) VALUES
(2, '168', 'testing-yatta', '2012-04-20 18:24:08', '0000-00-00 00:00:00', 1),
(3, '9879', 'mcp', '2012-07-26 10:48:13', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `attribute`
--

CREATE TABLE IF NOT EXISTS `attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `attribute`
--

INSERT INTO `attribute` (`id`, `name`) VALUES
(1, 'rereg_welcome'),
(2, 'rereg_rbt'),
(3, 'msg_isregistered'),
(4, 'pull_member'),
(5, 'msg_pull_notregistered'),
(6, 'rereg_content'),
(8, 'msg_unreg_notregistered'),
(9, 'wapdownload_name'),
(10, 'wapdownload_limit');

-- --------------------------------------------------------

--
-- Table structure for table `charging`
--

CREATE TABLE IF NOT EXISTS `charging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operator` int(11) NOT NULL,
  `adn` char(10) NOT NULL,
  `charging_id` varchar(128) NOT NULL,
  `gross` decimal(10,2) NOT NULL,
  `netto` decimal(10,2) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `sender_type` varchar(20) NOT NULL,
  `message_type` varchar(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `operator` (`operator`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Triggers `charging`
--
DROP TRIGGER IF EXISTS `xmp`.`trigger_charging`;
DELIMITER //
CREATE TRIGGER `xmp`.`trigger_charging` AFTER INSERT ON `xmp`.`charging`
 FOR EACH ROW BEGIN
    insert into service_charging_mapping (select id,new.id from service);
    END
//
DELIMITER ;

--
-- Dumping data for table `charging`
--

INSERT INTO `charging` (`id`, `operator`, `adn`, `charging_id`, `gross`, `netto`, `username`, `password`, `sender_type`, `message_type`, `date_created`, `date_modified`) VALUES
(9, 1, '168', '168SMSMO0', 0.00, 0.00, 'yatta', '7l4g8v', 'mo', 'mo', '2012-04-20 18:33:27', '2012-04-20 18:33:27'),
(10, 1, '168', '168SMSPULL350', 350.00, 350.00, 'yatta', '7l4g8v', 'text', 'mtpull', '2012-04-20 18:34:31', '2012-04-20 18:34:31'),
(12, 1, '168', '168SMSPUSH500', 500.00, 500.00, 'yatta', '7l4g8v', 'push', 'mtpush', '2012-04-20 19:56:16', '2012-04-20 19:56:16'),
(13, 1, '9879', '9879SMSPUSH2000', 2000.00, 2000.00, 'yattaera', 'yattaera', 'push', 'mtpush', '2012-07-26 10:50:01', '2012-07-26 10:50:01'),
(14, 1, '9879', '9879SMSPUSH0', 0.00, 0.00, 'yattaera', 'yattaera', 'push', 'mtpush', '2012-07-26 10:54:52', '2012-07-26 10:54:52'),
(15, 1, '9879', '9879SMSPULL0', 0.00, 0.00, 'yattaera', 'yattaera', 'text', 'mtpull', '2012-07-26 10:58:09', '2012-07-26 10:58:09'),
(16, 1, '9879', '9879SMSPULL1000', 1000.00, 1000.00, 'yattaera', 'yattaera', 'text', 'mtpull', '2012-07-26 11:20:03', '2012-07-26 11:20:03'),
(17, 1, '9879', '9879SMSPUSH2000', 2000.00, 2000.00, 'yattaera', 'yattaera', 'push', 'dailypush', '2012-07-26 10:50:01', '2012-07-26 10:50:01'),
(18, 1, '9879', '9879SMSPUSH0', 0.00, 0.00, 'yattaera', 'yattaera', 'push', 'dailypush', '2012-07-26 10:50:01', '2012-07-26 10:50:01');

-- --------------------------------------------------------

--
-- Table structure for table `creator_config`
--

CREATE TABLE IF NOT EXISTS `creator_config` (
  `mechanism_id` int(11) NOT NULL,
  `operator_id` int(11) NOT NULL,
  `meta_id` int(11) NOT NULL,
  `meta_value` varchar(255) NOT NULL,
  UNIQUE KEY `service_id` (`mechanism_id`,`meta_id`,`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `creator_config`
--


-- --------------------------------------------------------

--
-- Table structure for table `creator_meta`
--

CREATE TABLE IF NOT EXISTS `creator_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `meta_key` varchar(255) NOT NULL,
  `meta_type` varchar(15) DEFAULT NULL,
  `meta_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `creator_meta`
--


-- --------------------------------------------------------

--
-- Table structure for table `creator_sysreply`
--

CREATE TABLE IF NOT EXISTS `creator_sysreply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mechanism_id` int(11) NOT NULL,
  `creator_meta_id` int(11) NOT NULL,
  `operator_id` int(11) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `message` varchar(160) DEFAULT NULL,
  `charging_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `creator_sysreply`
--


-- --------------------------------------------------------

--
-- Table structure for table `custom_handler`
--

CREATE TABLE IF NOT EXISTS `custom_handler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `handler` varchar(50) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `custom_handler`
--

INSERT INTO `custom_handler` (`id`, `name`, `handler`, `status`) VALUES
(1, 'fun', 'service_custom_clubfun', '1'),
(2, 'sim', 'service_custom_sim', '1'),
(3, 'sair', 'service_custom_sair', '1'),
(4, 'ajuda', 'service_custom_ajuda', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mechanism`
--

CREATE TABLE IF NOT EXISTS `mechanism` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pattern` varchar(128) NOT NULL,
  `operator_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `handler` varchar(50) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `operator_mechanism_map` (`operator_id`),
  KEY `service_id_map` (`service_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `mechanism`
--

INSERT INTO `mechanism` (`id`, `pattern`, `operator_id`, `service_id`, `handler`, `date_created`, `date_modified`, `status`) VALUES
(7, 'reg tsyt', 1, 7, 'service_creator_handler', '2012-04-20 18:36:36', '2012-04-20 19:58:28', 1),
(8, 'unreg tsyt', 1, 7, 'service_creator_handler', '2012-04-20 18:37:43', '2012-04-20 19:27:23', 1),
(9, 'tsyt pull', 1, 7, 'service_creator_handler', '2012-04-20 18:38:23', '2012-04-20 18:38:23', 1),
(12, 'adzan', 1, 8, 'service_creator_handler', '2012-07-26 11:20:56', '2012-08-08 11:39:24', 1),
(13, 'reg adzan', 1, 8, 'service_creator_handler', '2012-07-26 11:54:55', '2012-08-08 11:58:36', 1),
(14, 'unreg adzan', 1, 8, 'service_creator_handler', '2012-07-26 11:55:35', '2012-08-02 10:38:25', 1),
(16, 'unreg bonus', 1, 10, 'service_creator_handler', '2012-08-02 11:42:35', '2012-08-02 11:42:35', 1),
(18, 'reg bonus', 1, 10, 'service_creator_handler', '2012-08-02 14:57:17', '2012-08-02 14:57:17', 1),
(19, 'reg bonuswap', 1, 13, 'service_creator_handler', '2012-08-07 19:16:16', '2012-08-07 19:16:16', 1),
(20, 'unreg bonuswap', 1, 13, 'service_creator_handler', '2012-08-07 19:18:53', '2012-08-07 19:18:53', 1),
(21, 'reg bonusumb', 1, 14, 'service_creator_handler', '2012-08-07 19:22:14', '2012-08-07 19:22:14', 1),
(22, 'unreg bonusumb', 1, 14, 'service_creator_handler', '2012-08-07 19:24:01', '2012-08-09 13:40:25', 1),
(23, 'reg adzanwap', 1, 15, 'service_creator_handler', '2012-08-08 17:04:52', '2012-08-08 17:04:52', 1),
(24, 'unreg adzanwap', 1, 15, 'service_creator_handler', '2012-08-08 17:07:05', '2012-08-08 17:07:05', 1),
(25, 'reg adzanumb', 1, 16, 'service_creator_handler', '2012-08-08 17:11:10', '2012-08-08 17:11:10', 1),
(26, 'unreg adzanumb', 1, 16, 'service_creator_handler', '2012-08-08 17:11:46', '2012-08-08 17:11:46', 1);

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(128) DEFAULT NULL,
  `handler` varchar(30) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`id`, `name`, `description`, `handler`, `date_created`, `date_modified`, `status`) VALUES
(1, 'text', '-', 'service_module_text', '2011-11-17 17:47:17', '2012-07-27 14:13:33', 1),
(8, 'registration', NULL, 'service_module_registration', '2011-11-24 18:07:36', '2011-11-24 18:07:36', 1),
(9, 'unregistration', NULL, 'service_module_unregistration', '2011-11-28 20:01:46', '2011-11-28 20:01:46', 1),
(10, 'waplink', NULL, 'service_module_waplink', '2011-11-29 16:54:08', '2011-11-29 16:54:08', 1),
(11, 'wappush', NULL, 'service_module_wappush', '2011-11-29 16:54:44', '2011-11-29 16:54:44', 1),
(12, 'textdelay', NULL, 'service_module_textdelay', '2011-12-05 16:36:00', '2011-12-05 16:36:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mo_delay`
--

CREATE TABLE IF NOT EXISTS `mo_delay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `obj` text NOT NULL,
  `service` varchar(10) NOT NULL,
  `adn` int(10) NOT NULL,
  `msisdn` varchar(32) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_expired` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mo_delay`
--

INSERT INTO `mo_delay` (`id`, `obj`, `service`, `adn`, `msisdn`, `date_created`, `date_expired`, `status`) VALUES
(1, 'O:11:"tim_mo_data":29:{s:10:"operatorId";s:1:"3";s:7:"inReply";N;s:5:"msgId";s:4:"9890";s:3:"adn";s:5:"43430";s:6:"msisdn";s:12:"021999067823";s:7:"msgData";s:3:"sim";s:13:"msgLastStatus";N;s:5:"retry";N;s:9:"msgStatus";N;s:11:"closeReason";N;s:9:"serviceId";N;s:5:"price";N;s:5:"media";N;s:7:"channel";s:3:"sms";s:7:"service";s:7:"clubfun";s:7:"partner";N;s:7:"keyword";s:3:"sim";s:12:"operatorName";s:3:"tim";s:6:"rawSMS";s:3:"sim";s:11:"requestType";s:3:"sim";s:12:"incomingDate";s:19:"2012-02-22 19:34:01";s:9:"parameter";N;s:4:"type";s:2:"mo";s:9:"patternId";s:1:"3";s:2:"id";N;s:8:"charging";N;s:7:"subject";N;s:8:"userData";N;s:10:"wapSession";N;}', 'clubfun', 43430, '021999067823', '2012-02-22 19:34:04', '2012-02-22 19:35:04', 0),
(2, 'O:11:"tim_mo_data":29:{s:10:"operatorId";s:1:"3";s:7:"inReply";N;s:5:"msgId";s:4:"9890";s:3:"adn";s:5:"43430";s:6:"msisdn";s:12:"021999067823";s:7:"msgData";s:3:"sim";s:13:"msgLastStatus";N;s:5:"retry";N;s:9:"msgStatus";N;s:11:"closeReason";N;s:9:"serviceId";N;s:5:"price";N;s:5:"media";N;s:7:"channel";s:3:"sms";s:7:"service";s:7:"clubfun";s:7:"partner";N;s:7:"keyword";s:3:"sim";s:12:"operatorName";s:3:"tim";s:6:"rawSMS";s:3:"sim";s:11:"requestType";s:3:"sim";s:12:"incomingDate";s:19:"2012-02-22 19:35:18";s:9:"parameter";N;s:4:"type";s:2:"mo";s:9:"patternId";s:1:"3";s:2:"id";N;s:8:"charging";N;s:7:"subject";N;s:8:"userData";N;s:10:"wapSession";N;}', 'clubfun', 43430, '021999067823', '2012-02-22 19:35:22', '2012-02-22 19:36:22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `operator`
--

CREATE TABLE IF NOT EXISTS `operator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `long_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `operator`
--

INSERT INTO `operator` (`id`, `name`, `long_name`) VALUES
(1, 'mcp', 'MCP');

-- --------------------------------------------------------

--
-- Table structure for table `reply`
--

CREATE TABLE IF NOT EXISTS `reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mechanism_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `charging_id` int(11) NOT NULL,
  `subject` varchar(10) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mechanism_map` (`mechanism_id`),
  KEY `module_map` (`module_id`),
  KEY `charging_id` (`charging_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=99 ;

--
-- Dumping data for table `reply`
--

INSERT INTO `reply` (`id`, `mechanism_id`, `module_id`, `charging_id`, `subject`, `message`) VALUES
(11, 9, 1, 10, ' ', 'pull yatta 350'),
(18, 8, 9, 10, ' ', 'Anda telah non-aktif di layanan kami'),
(27, 7, 8, 10, ' ', 'welcome yatta-test'),
(28, 7, 1, 12, ' ', 'push yatta 500'),
(42, 14, 9, 15, ' ', 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.'),
(45, 16, 9, 15, ' ', 'Status registrasi Anda di layanan BONUS telah kami non-aktifkan. Terima kasih atas partisipasi Anda'),
(57, 18, 8, 15, ' ', 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396'),
(58, 18, 1, 13, ' ', 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.'),
(78, 19, 8, 15, ' ', 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396'),
(79, 19, 1, 13, ' ', 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.'),
(80, 20, 9, 15, ' ', 'Status registrasi Anda di layanan BONUSWAP telah kami non-aktifkan. Terima kasih atas partisipasi Anda'),
(81, 21, 8, 15, ' ', 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396'),
(82, 21, 1, 13, ' ', 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu'),
(87, 12, 1, 16, ' ', ' http://m.marimain.com/ytfree/?c=5814'),
(90, 13, 8, 15, ' ', 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396'),
(91, 13, 1, 13, ' ', 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814'),
(92, 23, 8, 15, ' ', 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396'),
(93, 23, 1, 13, ' ', 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814'),
(94, 24, 9, 15, ' ', 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.'),
(95, 25, 8, 15, ' ', 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396'),
(96, 25, 1, 13, ' ', 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814'),
(97, 26, 9, 15, ' ', 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.'),
(98, 22, 9, 15, ' ', 'Status registrasi Anda di layanan BONUSUMB telah kami non-aktifkan. Terima kasih atas partisipasi Anda');

-- --------------------------------------------------------

--
-- Table structure for table `reply_attribute`
--

CREATE TABLE IF NOT EXISTS `reply_attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `reply_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_map` (`attribute_id`),
  KEY `reply_id_map` (`reply_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `reply_attribute`
--

INSERT INTO `reply_attribute` (`id`, `attribute_id`, `value`, `reply_id`) VALUES
(18, 8, 'rrrrr', 11),
(20, 4, '1', 1),
(30, 8, 'anda tidak terdaftar.. daftar donk..', 18),
(33, 8, 'Anda tidak terdaftar. Reg ADZAN ke 9879 untuk mendaftar', 42),
(34, 8, 'Anda tidak terdaftar. Reg BONUS ke 9879 untuk mendaftar', 45),
(47, 1, '1', 57),
(48, 3, 'Anda masih terdaftar di layanan Bonus', 57),
(51, 1, '1', 78),
(52, 3, 'Anda masih terdaftar di layanan Bonus', 78),
(53, 8, 'Anda tidak terdaftar. Reg BONUSWAP ke 9879 untuk mendaftar', 80),
(54, 1, '1', 81),
(55, 3, 'Anda masih terdaftar di layanan Bonus', 81),
(62, 1, '1', 90),
(63, 3, 'Anda masih terdaftar di layanan adzan', 90),
(64, 1, '1', 92),
(65, 3, 'Anda masih terdaftar di layanan adzan', 92),
(66, 8, 'Anda tidak terdaftar. Reg ADZAN ke 9879 untuk mendaftar', 94),
(67, 1, '1', 95),
(68, 3, 'Anda masih terdaftar di layanan adzan', 95),
(69, 8, 'Anda tidak terdaftar. Reg ADZAN ke 9879 untuk mendaftar', 97),
(70, 8, 'Anda tidak terdaftar. Reg BONUSUMB ke 9879 untuk mendaftar', 98);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE IF NOT EXISTS `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `adn` varchar(10) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Triggers `service`
--
DROP TRIGGER IF EXISTS `xmp`.`trigger_service`;
DELIMITER //
CREATE TRIGGER `xmp`.`trigger_service` AFTER INSERT ON `xmp`.`service`
 FOR EACH ROW BEGIN
    insert into service_charging_mapping (select new.id,id from charging);
    END
//
DELIMITER ;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `name`, `adn`, `date_created`, `date_modified`) VALUES
(7, 'KLBJTSYT', '168', '2012-04-20 18:31:24', '0000-00-00 00:00:00'),
(8, 'YATTADZA', '9879', '2012-07-26 11:05:22', '2012-08-02 09:03:44'),
(9, 'YATTAMUSI', '9879', '2012-07-27 11:09:46', '0000-00-00 00:00:00'),
(10, 'YATTBONU', '9879', '2012-08-02 11:37:58', '0000-00-00 00:00:00'),
(13, 'YATTBOWA', '9879', '2012-08-07 19:11:57', '0000-00-00 00:00:00'),
(14, 'YATTBOUM', '9879', '2012-08-07 19:19:47', '0000-00-00 00:00:00'),
(15, 'YATTADWA', '9879', '2012-08-08 17:02:59', '0000-00-00 00:00:00'),
(16, 'YATTAZUM', '9879', '2012-08-08 17:08:00', '2012-08-09 14:14:42');

-- --------------------------------------------------------

--
-- Table structure for table `service_charging_mapping`
--

CREATE TABLE IF NOT EXISTS `service_charging_mapping` (
  `service_id` int(11) NOT NULL,
  `charging_id` int(11) NOT NULL,
  PRIMARY KEY (`service_id`,`charging_id`),
  KEY `charging_id` (`charging_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_charging_mapping`
--

INSERT INTO `service_charging_mapping` (`service_id`, `charging_id`) VALUES
(7, 9),
(8, 9),
(9, 9),
(10, 9),
(13, 9),
(14, 9),
(15, 9),
(16, 9),
(7, 10),
(8, 10),
(9, 10),
(10, 10),
(13, 10),
(14, 10),
(15, 10),
(16, 10),
(7, 12),
(8, 12),
(9, 12),
(10, 12),
(13, 12),
(14, 12),
(15, 12),
(16, 12),
(7, 13),
(8, 13),
(9, 13),
(10, 13),
(13, 13),
(14, 13),
(15, 13),
(16, 13),
(7, 14),
(8, 14),
(9, 14),
(10, 14),
(13, 14),
(14, 14),
(15, 14),
(16, 14),
(7, 15),
(8, 15),
(9, 15),
(10, 15),
(13, 15),
(14, 15),
(15, 15),
(16, 15),
(7, 16),
(8, 16),
(9, 16),
(10, 16),
(13, 16),
(14, 16),
(15, 16),
(16, 16),
(7, 17),
(8, 17),
(9, 17),
(10, 17),
(13, 17),
(14, 17),
(15, 17),
(16, 17),
(7, 18),
(8, 18),
(9, 18),
(10, 18),
(13, 18),
(14, 18),
(15, 18),
(16, 18);

-- --------------------------------------------------------

--
-- Table structure for table `service_old`
--

CREATE TABLE IF NOT EXISTS `service_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `adn` varchar(10) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `service_old`
--

INSERT INTO `service_old` (`id`, `name`, `adn`, `date_created`, `date_modified`) VALUES
(1, 'ERROR', '9790', '2011-06-30 12:17:13', '2011-12-07 15:03:22'),
(2, 'clubfun', '43430', '2011-06-30 12:17:13', '0000-00-00 00:00:00'),
(3, 'clubfun', '88002', '2011-08-25 19:55:58', '2011-08-25 19:55:58'),
(4, 'clubfun', '27404', '2011-08-25 19:56:30', '2011-08-25 19:56:30'),
(15, 'divino', '43430', '2011-12-23 13:54:21', '0000-00-00 00:00:00'),
(16, 'DFJIFUN', '9790', '2012-04-02 14:44:50', '2012-04-02 14:44:50'),
(17, 'DFJIFUN', '9790', '2012-04-13 20:40:03', '2012-04-13 20:40:03'),
(18, 'ERROR', '9790', '2011-06-30 12:17:13', '2011-12-07 15:03:22'),
(19, 'DFJIFUN', '9790', '2012-04-02 14:44:50', '2012-04-02 14:44:50');

-- --------------------------------------------------------

--
-- Table structure for table `service_point`
--

CREATE TABLE IF NOT EXISTS `service_point` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint(20) NOT NULL,
  `point` int(11) NOT NULL,
  `time_created` datetime NOT NULL,
  `time_updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `service_point`
--


-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE IF NOT EXISTS `subscription` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id_subscribe` varchar(64) NOT NULL,
  `transaction_id_unsubscribe` varchar(64) NOT NULL,
  `msisdn` varchar(32) NOT NULL,
  `service` varchar(64) NOT NULL,
  `adn` varchar(8) NOT NULL,
  `operator` varchar(32) NOT NULL,
  `channel_subscribe` varchar(16) NOT NULL,
  `channel_unsubscribe` varchar(16) NOT NULL,
  `subscribed_from` datetime NOT NULL,
  `subscribed_until` datetime NOT NULL,
  `partner` varchar(20) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time_updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `msisdn` (`msisdn`) USING BTREE,
  KEY `service` (`service`) USING BTREE,
  KEY `short_code` (`adn`) USING BTREE,
  KEY `operator` (`operator`) USING BTREE,
  KEY `active` (`active`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=123 ;

--
-- Dumping data for table `subscription`
--

INSERT INTO `subscription` (`id`, `transaction_id_subscribe`, `transaction_id_unsubscribe`, `msisdn`, `service`, `adn`, `operator`, `channel_subscribe`, `channel_unsubscribe`, `subscribed_from`, `subscribed_until`, `partner`, `active`, `time_created`, `time_updated`) VALUES
(1, '67', '69', '62925455930734', 'FUNN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 11:29:01', '2012-04-16 11:54:01', '', 2, '2012-04-16 11:29:01', '2012-04-16 11:54:01'),
(2, '71', '73', '62925455930734', 'FUNN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 12:02:01', '2012-04-16 12:16:01', '', 2, '2012-04-16 12:02:01', '2012-04-16 12:16:01'),
(3, '75', '77', '62925455930734', 'FUNN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 12:21:01', '2012-04-16 12:26:01', '', 2, '2012-04-16 12:21:01', '2012-04-16 12:26:01'),
(4, '79', '81', '62925455930734', 'FUNN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 12:27:01', '2012-04-16 12:34:01', '', 2, '2012-04-16 12:27:01', '2012-04-16 12:34:01'),
(5, '82', '', '62925455930734', 'FUNN', '9790', 'mcp', 'sms', '', '2012-04-16 12:34:01', '9999-12-31 00:00:00', '', 1, '2012-04-16 12:34:01', '0000-00-00 00:00:00'),
(6, '85', '', '62925450115551', 'FUNN', '9790', 'mcp', 'sms', '', '2012-04-16 13:26:01', '9999-12-31 00:00:00', '', 1, '2012-04-16 13:26:01', '0000-00-00 00:00:00'),
(7, '89', '91', '925455930734', 'FUNN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 15:24:02', '2012-04-16 15:27:01', '', 2, '2012-04-16 15:24:02', '2012-04-16 15:27:01'),
(8, '97', '', '9254533996900', 'FUNN', '9790', 'mcp', 'sms', '', '2012-04-16 16:04:01', '9999-12-31 00:00:00', '', 1, '2012-04-16 16:04:01', '0000-00-00 00:00:00'),
(9, '99', '101', '925455930734', 'FUNN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 16:11:01', '2012-04-16 16:12:01', '', 2, '2012-04-16 16:11:01', '2012-04-16 16:12:01'),
(10, '103', '', '925455930734', 'FUNN', '9790', 'mcp', 'sms', '', '2012-04-16 16:14:01', '9999-12-31 00:00:00', '', 1, '2012-04-16 16:14:01', '0000-00-00 00:00:00'),
(11, '111', '115', '925455930734', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 16:52:01', '2012-04-16 17:01:01', '', 2, '2012-04-16 16:52:01', '2012-04-16 17:01:01'),
(12, '117', '127', '925455930734', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 17:06:01', '2012-04-16 17:26:01', '', 2, '2012-04-16 17:06:01', '2012-04-16 17:26:01'),
(13, '123', '', '925450115551', 'DFJIFUN', '9790', 'mcp', 'sms', '', '2012-04-16 17:16:01', '9999-12-31 00:00:00', '', 1, '2012-04-16 17:16:01', '0000-00-00 00:00:00'),
(14, '129', '159', '925455930734', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 17:27:01', '2012-04-17 11:55:01', '', 2, '2012-04-16 17:27:01', '2012-04-17 11:55:01'),
(15, '137', '141', '925455110098', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 19:40:02', '2012-04-16 19:44:01', '', 2, '2012-04-16 19:40:02', '2012-04-16 19:44:01'),
(16, '142', '149', '925455110098', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 19:44:01', '2012-04-16 19:49:01', '', 2, '2012-04-16 19:44:01', '2012-04-16 19:49:01'),
(17, '151', '157', '925455110098', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-16 19:52:01', '2012-04-16 19:57:01', '', 2, '2012-04-16 19:52:01', '2012-04-16 19:57:01'),
(18, '163', '', '9254532828073', 'DFJIFUN', '9790', 'mcp', 'sms', '', '2012-04-17 14:35:01', '9999-12-31 00:00:00', '', 1, '2012-04-17 14:35:01', '0000-00-00 00:00:00'),
(19, '169', '175', '925455930734', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-17 14:49:01', '2012-04-17 16:31:02', '', 2, '2012-04-17 14:49:01', '2012-04-17 16:31:02'),
(20, '181', '217', '925455930795', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-17 20:10:02', '2012-04-18 16:42:01', '', 2, '2012-04-17 20:10:02', '2012-04-18 16:42:01'),
(21, '185', '229', '9254571055793', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-17 20:28:02', '2012-04-19 15:01:02', '', 2, '2012-04-17 20:28:02', '2012-04-19 15:01:02'),
(22, '193', '209', '925455110098', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-18 11:40:01', '2012-04-18 11:54:01', '', 2, '2012-04-18 11:40:01', '2012-04-18 11:54:01'),
(23, '199', '207', '925455930734', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-18 11:44:01', '2012-04-18 11:51:01', '', 2, '2012-04-18 11:44:01', '2012-04-18 11:51:01'),
(24, '203', '', '925455930736', 'DFJIFUN', '9790', 'mcp', 'sms', '', '2012-04-18 11:45:01', '9999-12-31 00:00:00', '', 1, '2012-04-18 11:45:02', '0000-00-00 00:00:00'),
(25, '211', '223', '925455930734', 'DFJIFUN', '9790', 'mcp', 'sms', 'sms', '2012-04-18 11:56:02', '2012-04-18 19:54:01', '', 2, '2012-04-18 11:56:02', '2012-04-18 19:54:01'),
(26, '219', '', '925455930795', 'DFJIFUN', '9790', 'mcp', 'sms', '', '2012-04-18 16:43:01', '9999-12-31 00:00:00', '', 1, '2012-04-18 16:43:01', '0000-00-00 00:00:00'),
(27, '231', '', '925455551296', 'DFJIFUN', '9790', 'mcp', 'sms', '', '2012-04-19 15:03:02', '9999-12-31 00:00:00', '', 1, '2012-04-19 15:03:02', '0000-00-00 00:00:00'),
(28, '235', '246', '9254571055793', 'KONTEN', '9790', 'mcp', 'sms', 'sms', '2012-04-19 16:01:04', '2012-04-19 16:37:01', '', 0, '2012-04-19 16:01:04', '2012-04-19 16:37:01'),
(29, '238', '', '9254538669341', 'KONTEN', '9790', 'mcp', 'sms', '', '2012-04-19 16:06:01', '9999-12-31 00:00:00', '', 1, '2012-04-19 16:06:01', '0000-00-00 00:00:00'),
(30, '247', '', '9254571055793', 'KONTEN', '9790', 'mcp', 'sms', '', '2012-04-19 16:37:01', '9999-12-31 00:00:00', '', 1, '2012-04-19 16:37:01', '0000-00-00 00:00:00'),
(31, '252', '', '925455551296', 'DFJIKONT', '9790', 'mcp', 'sms', '', '2012-04-19 16:58:01', '9999-12-31 00:00:00', '', 1, '2012-04-19 16:58:01', '0000-00-00 00:00:00'),
(32, '256', '', '9254538669341', 'DFJIKONT', '9790', 'mcp', 'sms', '', '2012-04-19 17:16:01', '9999-12-31 00:00:00', '', 1, '2012-04-19 17:16:01', '0000-00-00 00:00:00'),
(33, '258', '261', '9254570601385', 'KLBJTSYT', '168', 'mcp', 'sms', 'sms', '2012-04-20 18:40:02', '2012-04-20 18:56:01', '', 0, '2012-04-20 18:40:02', '2012-04-20 18:56:01'),
(34, '262', '266', '9254533996900', 'KLBJTSYT', '168', 'mcp', 'sms', 'sms', '2012-04-20 19:16:02', '2012-04-20 19:26:01', '', 0, '2012-04-20 19:16:02', '2012-04-20 19:26:01'),
(35, '267', '270', '9254533996900', 'KLBJTSYT', '168', 'mcp', 'sms', 'sms', '2012-04-20 19:30:01', '2012-04-20 19:37:01', '', 0, '2012-04-20 19:30:01', '2012-04-20 19:37:01'),
(36, '272', '275', '9254533996900', 'KLBJTSYT', '168', 'mcp', 'sms', 'sms', '2012-04-20 19:39:01', '2012-04-20 19:56:01', '', 0, '2012-04-20 19:39:01', '2012-04-20 19:56:01'),
(37, '277', '280', '9254533996900', 'KLBJTSYT', '168', 'mcp', 'sms', 'sms', '2012-04-20 20:01:03', '2012-04-20 20:03:01', '', 0, '2012-04-20 20:01:03', '2012-04-20 20:03:01'),
(38, '288', '292', '9254570601385', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-07-26 13:36:01', '2012-07-26 13:43:01', '', 0, '2012-07-26 13:36:01', '2012-07-26 13:43:01'),
(39, '296', '307', '9254570618858', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-07-26 14:25:01', '2012-07-26 14:31:01', '', 0, '2012-07-26 14:25:01', '2012-07-26 14:31:01'),
(40, '299', '358', '9254570601385', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-07-26 14:27:01', '2012-08-01 11:33:01', '', 0, '2012-07-26 14:27:01', '2012-08-01 11:33:01'),
(41, '314', '319', '9254573501052', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-07-26 15:05:01', '2012-07-26 15:12:01', '', 0, '2012-07-26 15:05:01', '2012-07-26 15:12:01'),
(42, '321', '325', '9254573501052', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-07-26 16:27:01', '2012-07-26 16:35:01', '', 0, '2012-07-26 16:27:02', '2012-07-26 16:35:01'),
(43, '327', '334', '9254573501052', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-07-28 05:28:01', '2012-07-28 05:33:01', '', 0, '2012-07-28 05:28:01', '2012-07-28 05:33:01'),
(44, '337', '342', '9254573501052', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-07-31 13:57:01', '2012-07-31 17:50:01', '', 0, '2012-07-31 13:57:01', '2012-07-31 17:50:01'),
(45, '344', '369', '9254573501052', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-07-31 17:52:02', '2012-08-02 10:58:01', '', 0, '2012-07-31 17:52:02', '2012-08-02 10:58:01'),
(46, '360', '', '9254570601385', 'YATTADZA', '9879', 'mcp', 'sms', '', '2012-08-01 11:35:01', '9999-12-31 00:00:00', '', 1, '2012-08-01 11:35:01', '0000-00-00 00:00:00'),
(47, '371', '387', '9254573501052', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-08-02 11:02:01', '2012-08-03 11:53:01', '', 0, '2012-08-02 11:02:01', '2012-08-03 11:53:01'),
(48, '376', '444', '9254573501052', 'YATTBONU', '9879', 'mcp', 'sms', 'sms', '2012-08-02 15:30:01', '2012-08-07 16:06:01', '', 0, '2012-08-02 15:30:01', '2012-08-07 16:06:01'),
(49, '385', '545', '9254573408913', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-08-03 11:29:01', '2012-08-09 17:00:01', '', 0, '2012-08-03 11:29:01', '2012-08-09 17:00:01'),
(50, '389', '423', '9254573501052', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-08-03 11:54:01', '2012-08-07 10:40:01', '', 0, '2012-08-03 11:54:01', '2012-08-07 10:40:01'),
(51, '408', '', '9254570601385', 'YATTBONU', '9879', 'mcp', 'sms', '', '2012-08-06 13:38:02', '9999-12-31 00:00:00', '', 1, '2012-08-06 13:38:02', '0000-00-00 00:00:00'),
(52, '414', '', '925455556977', 'YATTADZA', '9879', 'mcp', 'sms', '', '2012-08-06 19:46:02', '9999-12-31 00:00:00', '', 1, '2012-08-06 19:46:02', '0000-00-00 00:00:00'),
(53, '425', '429', '9254573501052', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-08-07 10:43:01', '2012-08-07 11:55:01', '', 0, '2012-08-07 10:43:01', '2012-08-07 11:55:01'),
(54, '431', '433', '9254573501052', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-08-07 11:56:01', '2012-08-07 15:50:01', '', 0, '2012-08-07 11:56:01', '2012-08-07 15:50:01'),
(55, '435', '', '9254573501052', 'YATTADZA', '9879', 'mcp', 'sms', '', '2012-08-07 15:51:01', '9999-12-31 00:00:00', '', 1, '2012-08-07 15:51:01', '0000-00-00 00:00:00'),
(56, '446', '', '9254573501052', 'YATTBONU', '9879', 'mcp', 'sms', '', '2012-08-07 16:08:01', '9999-12-31 00:00:00', '', 1, '2012-08-07 16:08:01', '0000-00-00 00:00:00'),
(57, '457', '460', '9254573408913', 'YATTBONU', '9879', 'mcp', 'sms', 'sms', '2012-08-08 15:01:03', '2012-08-08 15:03:01', '', 0, '2012-08-08 15:01:03', '2012-08-08 15:03:01'),
(58, '473', '484', '9254573501052', 'YATTADWA', '9879', 'mcp', 'sms', 'sms', '2012-08-09 11:45:01', '2012-08-09 11:57:02', '', 0, '2012-08-09 11:45:01', '2012-08-09 11:57:02'),
(59, '474', '482', '9254573501052', 'YATTADUM', '9879', 'mcp', 'sms', 'sms', '2012-08-09 11:45:01', '2012-08-09 11:53:02', '', 0, '2012-08-09 11:45:01', '2012-08-09 11:53:02'),
(60, '476', '', '9254508888515', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-09 11:45:01', '9999-12-31 00:00:00', '', 1, '2012-08-09 11:45:01', '0000-00-00 00:00:00'),
(61, '486', '489', '9254573501052', 'YATTADWA', '9879', 'mcp', 'sms', 'sms', '2012-08-09 12:00:01', '2012-08-09 12:01:04', '', 0, '2012-08-09 12:00:01', '2012-08-09 12:01:04'),
(62, '491', '', '9254573501052', 'YATTADUM', '9879', 'mcp', 'sms', '', '2012-08-09 12:08:01', '9999-12-31 00:00:00', '', 1, '2012-08-09 12:08:01', '0000-00-00 00:00:00'),
(63, '496', '', '9254573501052', 'YATTAZUM', '9879', 'mcp', 'sms', '', '2012-08-09 12:19:01', '9999-12-31 00:00:00', '', 1, '2012-08-09 12:19:01', '0000-00-00 00:00:00'),
(64, '500', '503', '9254573501052', 'YATTBOWA', '9879', 'mcp', 'sms', 'sms', '2012-08-09 12:21:01', '2012-08-09 12:22:01', '', 0, '2012-08-09 12:21:01', '2012-08-09 12:22:01'),
(65, '505', '', '9254573501052', 'YATTBOUM', '9879', 'mcp', 'sms', '', '2012-08-09 12:23:02', '9999-12-31 00:00:00', '', 1, '2012-08-09 12:23:02', '0000-00-00 00:00:00'),
(66, '509', '', '9254573501052', 'YATTADWA', '9879', 'mcp', 'sms', '', '2012-08-09 14:05:01', '9999-12-31 00:00:00', '', 1, '2012-08-09 14:05:01', '0000-00-00 00:00:00'),
(67, '513', '519', '9254517808171', 'YATTADWA', '9879', 'mcp', 'sms', 'sms', '2012-08-09 14:55:01', '2012-08-09 15:08:02', '', 0, '2012-08-09 14:55:01', '2012-08-09 15:08:02'),
(68, '516', '521', '9254517808171', 'YATTADUM', '9879', 'mcp', 'sms', 'sms', '2012-08-09 15:05:01', '2012-08-09 15:21:01', '', 0, '2012-08-09 15:05:01', '2012-08-09 15:21:01'),
(69, '523', '526', '9254517808171', 'YATTADZA', '9879', 'mcp', 'sms', 'sms', '2012-08-09 15:28:01', '2012-08-09 15:32:01', '', 0, '2012-08-09 15:28:01', '2012-08-09 15:32:01'),
(70, '528', '554', '9254517808171', 'YATTADUM', '9879', 'mcp', 'sms', 'sms', '2012-08-09 15:38:02', '2012-08-09 17:08:01', '', 0, '2012-08-09 15:38:02', '2012-08-09 17:08:01'),
(71, '540', '543', '9254517808171', 'YATTBONU', '9879', 'mcp', 'sms', 'sms', '2012-08-09 16:44:01', '2012-08-09 16:48:01', '', 0, '2012-08-09 16:44:01', '2012-08-09 16:48:01'),
(72, '547', '', '9254573408913', 'YATTADUM', '9879', 'mcp', 'sms', '', '2012-08-09 17:01:05', '9999-12-31 00:00:00', '', 1, '2012-08-09 17:01:05', '0000-00-00 00:00:00'),
(73, '556', '', '9254517808171', 'YATTADUM', '9879', 'mcp', 'sms', '', '2012-08-09 17:10:01', '9999-12-31 00:00:00', '', 1, '2012-08-09 17:10:01', '0000-00-00 00:00:00'),
(74, '561', '', '9254517808171', 'YATTAZUM', '9879', 'mcp', 'sms', '', '2012-08-09 17:31:01', '9999-12-31 00:00:00', '', 1, '2012-08-09 17:31:01', '0000-00-00 00:00:00'),
(75, '575', '', '9254533149665', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-10 14:36:02', '9999-12-31 00:00:00', '', 1, '2012-08-10 14:36:02', '0000-00-00 00:00:00'),
(76, '578', '', '9254504412485', 'YATTADWA', '9879', 'mcp', 'sms', '', '2012-08-10 15:15:02', '9999-12-31 00:00:00', '', 1, '2012-08-10 15:15:02', '0000-00-00 00:00:00'),
(77, '581', '', '9254504697019', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-10 16:32:01', '9999-12-31 00:00:00', '', 1, '2012-08-10 16:32:01', '0000-00-00 00:00:00'),
(78, '584', '', '9254500375318', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-10 16:34:01', '9999-12-31 00:00:00', '', 1, '2012-08-10 16:34:01', '0000-00-00 00:00:00'),
(79, '587', '', '9254590490782', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-10 16:47:01', '9999-12-31 00:00:00', '', 1, '2012-08-10 16:47:01', '0000-00-00 00:00:00'),
(80, '596', '', '9254539505515', 'YATTADWA', '9879', 'mcp', 'sms', '', '2012-08-10 17:27:01', '9999-12-31 00:00:00', '', 1, '2012-08-10 17:27:01', '0000-00-00 00:00:00'),
(81, '599', '', '9254538756100', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-10 17:37:01', '9999-12-31 00:00:00', '', 1, '2012-08-10 17:37:01', '0000-00-00 00:00:00'),
(82, '602', '', '9254527532980', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-10 21:04:02', '9999-12-31 00:00:00', '', 1, '2012-08-10 21:04:02', '0000-00-00 00:00:00'),
(83, '605', '', '9254577634131', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-10 21:18:01', '9999-12-31 00:00:00', '', 1, '2012-08-10 21:18:01', '0000-00-00 00:00:00'),
(84, '608', '', '9254504571278', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-10 23:08:02', '9999-12-31 00:00:00', '', 1, '2012-08-10 23:08:02', '0000-00-00 00:00:00'),
(85, '611', '', '9254031971602', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-11 01:02:02', '9999-12-31 00:00:00', '', 1, '2012-08-11 01:02:02', '0000-00-00 00:00:00'),
(86, '614', '', '9254537090415', 'YATTADWA', '9879', 'mcp', 'sms', '', '2012-08-11 03:45:01', '9999-12-31 00:00:00', '', 1, '2012-08-11 03:45:01', '0000-00-00 00:00:00'),
(87, '628', '', '9254036678642', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-11 10:45:01', '9999-12-31 00:00:00', '', 1, '2012-08-11 10:45:01', '0000-00-00 00:00:00'),
(88, '631', '', '9254097965847', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-11 11:57:01', '9999-12-31 00:00:00', '', 1, '2012-08-11 11:57:01', '0000-00-00 00:00:00'),
(89, '634', '', '9254502995305', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-11 14:20:01', '9999-12-31 00:00:00', '', 1, '2012-08-11 14:20:01', '0000-00-00 00:00:00'),
(90, '646', '', '9254521211079', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-11 20:31:01', '9999-12-31 00:00:00', '', 1, '2012-08-11 20:31:01', '0000-00-00 00:00:00'),
(91, '649', '', '9254504236476', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-11 23:23:03', '9999-12-31 00:00:00', '', 1, '2012-08-11 23:23:03', '0000-00-00 00:00:00'),
(92, '652', '', '9254521744990', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-12 01:59:01', '9999-12-31 00:00:00', '', 1, '2012-08-12 01:59:01', '0000-00-00 00:00:00'),
(93, '655', '', '9254589318948', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-12 04:47:02', '9999-12-31 00:00:00', '', 1, '2012-08-12 04:47:02', '0000-00-00 00:00:00'),
(94, '658', '', '9254509153542', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-12 06:18:02', '9999-12-31 00:00:00', '', 1, '2012-08-12 06:18:02', '0000-00-00 00:00:00'),
(95, '672', '', '9254521248377', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-12 08:56:02', '9999-12-31 00:00:00', '', 1, '2012-08-12 08:56:02', '0000-00-00 00:00:00'),
(96, '675', '', '9254571249321', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-12 11:01:03', '9999-12-31 00:00:00', '', 1, '2012-08-12 11:01:03', '0000-00-00 00:00:00'),
(97, '678', '', '9254538343381', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-12 13:30:01', '9999-12-31 00:00:00', '', 1, '2012-08-12 13:30:01', '0000-00-00 00:00:00'),
(98, '681', '', '9254534994375', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-12 14:56:02', '9999-12-31 00:00:00', '', 1, '2012-08-12 14:56:02', '0000-00-00 00:00:00'),
(99, '684', '', '9254575321908', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-12 16:05:01', '9999-12-31 00:00:00', '', 1, '2012-08-12 16:05:01', '0000-00-00 00:00:00'),
(100, '696', '', '9254500913144', 'YATTADWA', '9879', 'mcp', 'sms', '', '2012-08-13 00:45:02', '9999-12-31 00:00:00', '', 1, '2012-08-13 00:45:02', '0000-00-00 00:00:00'),
(101, '700', '', '92545039851', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 01:12:01', '9999-12-31 00:00:00', '', 1, '2012-08-13 01:12:01', '0000-00-00 00:00:00'),
(102, '699', '', '9254526878543', 'YATTADWA', '9879', 'mcp', 'sms', '', '2012-08-13 01:12:01', '9999-12-31 00:00:00', '', 1, '2012-08-13 01:12:01', '0000-00-00 00:00:00'),
(103, '705', '', '9254538669341', 'YATTBONU', '9879', 'mcp', 'sms', '', '2012-08-13 01:42:01', '9999-12-31 00:00:00', '', 1, '2012-08-13 01:42:01', '0000-00-00 00:00:00'),
(104, '708', '', '9254533411159', 'YATTBONU', '9879', 'mcp', 'sms', '', '2012-08-13 01:44:01', '9999-12-31 00:00:00', '', 1, '2012-08-13 01:44:01', '0000-00-00 00:00:00'),
(105, '712', '', '9254520392140', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 02:14:02', '9999-12-31 00:00:00', '', 1, '2012-08-13 02:14:02', '0000-00-00 00:00:00'),
(106, '715', '', '9254580297861', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 04:24:02', '9999-12-31 00:00:00', '', 1, '2012-08-13 04:24:02', '0000-00-00 00:00:00'),
(107, '729', '', '9254574097177', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 10:11:01', '9999-12-31 00:00:00', '', 1, '2012-08-13 10:11:01', '0000-00-00 00:00:00'),
(108, '732', '', '9254504821604', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 10:32:02', '9999-12-31 00:00:00', '', 1, '2012-08-13 10:32:02', '0000-00-00 00:00:00'),
(109, '735', '', '9254565474845', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 11:28:01', '9999-12-31 00:00:00', '', 1, '2012-08-13 11:28:01', '0000-00-00 00:00:00'),
(110, '738', '', '9254535174348', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 14:22:02', '9999-12-31 00:00:00', '', 1, '2012-08-13 14:22:02', '0000-00-00 00:00:00'),
(111, '741', '', '9254508546470', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 16:21:02', '9999-12-31 00:00:00', '', 1, '2012-08-13 16:21:02', '0000-00-00 00:00:00'),
(112, '744', '', '9254031856005', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 16:49:01', '9999-12-31 00:00:00', '', 1, '2012-08-13 16:49:01', '0000-00-00 00:00:00'),
(113, '756', '', '9254546963779', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 17:56:01', '9999-12-31 00:00:00', '', 1, '2012-08-13 17:56:01', '0000-00-00 00:00:00'),
(114, '759', '', '9254564184070', 'YATTADWA', '9879', 'mcp', 'sms', '', '2012-08-13 18:41:02', '9999-12-31 00:00:00', '', 1, '2012-08-13 18:41:02', '0000-00-00 00:00:00'),
(115, '762', '', '92545364191', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 19:19:02', '9999-12-31 00:00:00', '', 1, '2012-08-13 19:19:02', '0000-00-00 00:00:00'),
(116, '765', '', '9254527451584', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 23:35:01', '9999-12-31 00:00:00', '', 1, '2012-08-13 23:35:01', '0000-00-00 00:00:00'),
(117, '768', '', '9254502436737', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-13 23:47:01', '9999-12-31 00:00:00', '', 1, '2012-08-13 23:47:01', '0000-00-00 00:00:00'),
(118, '778', '', '9254051646760', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-14 08:09:02', '9999-12-31 00:00:00', '', 1, '2012-08-14 08:09:02', '0000-00-00 00:00:00'),
(119, '781', '', '9254536869774', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-14 11:43:01', '9999-12-31 00:00:00', '', 1, '2012-08-14 11:43:01', '0000-00-00 00:00:00'),
(120, '784', '', '9254577090486', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-14 12:15:02', '9999-12-31 00:00:00', '', 1, '2012-08-14 12:15:02', '0000-00-00 00:00:00'),
(121, '787', '', '9254508944589', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-14 20:48:02', '9999-12-31 00:00:00', '', 1, '2012-08-14 20:48:02', '0000-00-00 00:00:00'),
(122, '790', '', '9254572112140', 'YATTBOWA', '9879', 'mcp', 'sms', '', '2012-08-14 20:57:02', '9999-12-31 00:00:00', '', 1, '2012-08-14 20:57:02', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_msgtransact`
--

CREATE TABLE IF NOT EXISTS `tbl_msgtransact` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `IN_REPLY_TO` bigint(20) NOT NULL DEFAULT '0',
  `MSGINDEX` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `MSGTIMESTAMP` datetime DEFAULT NULL,
  `ADN` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `MSISDN` varchar(15) CHARACTER SET latin1 DEFAULT NULL,
  `OPERATORID` int(11) NOT NULL,
  `MSGDATA` varchar(160) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `MSGLASTSTATUS` varchar(15) CHARACTER SET latin1 DEFAULT NULL,
  `MSGSTATUS` varchar(25) CHARACTER SET latin1 DEFAULT NULL,
  `CLOSEREASON` varchar(128) CHARACTER SET latin1 DEFAULT NULL,
  `SERVICEID` varchar(41) CHARACTER SET latin1 DEFAULT NULL,
  `MEDIA` varchar(12) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `CHANNEL` varchar(12) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `SERVICE` varchar(25) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `PARTNER` varchar(25) CHARACTER SET latin1 DEFAULT NULL,
  `SUBJECT` varchar(128) CHARACTER SET latin1 DEFAULT NULL,
  `PRICE` float NOT NULL,
  `ISR` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IX_TBL_MSGTRANSACT` (`MSGINDEX`,`MSGLASTSTATUS`),
  KEY `waktu` (`MSGTIMESTAMP`),
  KEY `from` (`ADN`),
  KEY `listview` (`SERVICE`,`MSGTIMESTAMP`),
  KEY `service` (`MEDIA`,`MSGTIMESTAMP`),
  KEY `IAC` (`ISR`),
  KEY `MSGLASTSTATUS` (`MSGLASTSTATUS`),
  KEY `MSGSTATUS` (`MSGSTATUS`),
  KEY `IN_REPLY_TO` (`IN_REPLY_TO`),
  KEY `PARTNER` (`PARTNER`),
  KEY `SUBJECT` (`SUBJECT`,`MSGTIMESTAMP`,`MSGSTATUS`,`SERVICE`,`PARTNER`),
  KEY `msgto` (`MSISDN`,`ADN`,`MSGTIMESTAMP`),
  KEY `MSGDATA` (`MSGDATA`,`SERVICE`,`MSGTIMESTAMP`,`SUBJECT`,`MSGSTATUS`),
  KEY `CS_SEARCH` (`ADN`,`MSISDN`,`SERVICE`,`MSGTIMESTAMP`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=800 ;

--
-- Dumping data for table `tbl_msgtransact`
--

INSERT INTO `tbl_msgtransact` (`ID`, `IN_REPLY_TO`, `MSGINDEX`, `MSGTIMESTAMP`, `ADN`, `MSISDN`, `OPERATORID`, `MSGDATA`, `MSGLASTSTATUS`, `MSGSTATUS`, `CLOSEREASON`, `SERVICEID`, `MEDIA`, `CHANNEL`, `SERVICE`, `PARTNER`, `SUBJECT`, `PRICE`, `ISR`) VALUES
(1, 0, '9852', '2012-04-02 16:36:18', '9877', '6281883334666', 5, 'reg anunya', NULL, '', '', '123PULL2000', '', 'sms', 'MAIN9877', '', 'MO;PULL;SMS;REG', 2000, 0),
(2, 1, '9852', '2012-04-02 16:40:11', '9877', '6281883334666', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message>\n<status>0</status>\n<tid>111121015238149919</tid>\n</message>\n', '126SMSPULL3000', '', 'sms', 'MAIN9877', '', 'MT;PULL;SMS;REG', 0, 0),
(3, 1, '2012040216395613333595963348', '2012-04-02 16:40:33', '9877', '6281883334666', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/m7qD http://m.kiosmobile.com/d/h/tk/m7qD', 'DELIVERED', '', '<message>\n<status>0</status>\n<tid>111121015238149919</tid>\n</message>\n', '123WAPPUSH2000', '', 'sms', 'MAIN9877', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(4, 1, '2012040216395613333595963348', '2012-04-02 16:40:34', '9877', '6281883334666', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/m7qD http://m.kiosmobile.com/d/h/tk/m7qD', 'DELIVERED', '', '<message>\n<status>0</status>\n<tid>111121015238149919</tid>\n</message>\n', '123WAPPUSH2000', '', 'sms', 'MAIN9877', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(5, 1, '9852', '2012-04-02 16:43:04', '9877', '6281883334666', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message>\n<status>0</status>\n<tid>111121015238149919</tid>\n</message>\n', '123SMSPUSH2000', '', 'sms', 'MAIN9877', '', 'MT;PUSH;SMS;REG', 2000, 0),
(6, 0, '<', '0000-00-00 00:00:00', '<', '62<', 5, '<', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(7, 0, '8008', '2012-04-03 15:42:57', '9877', '62228887777777', 5, 'reg sapi', NULL, '', '', '123PULL2000', '', 'sms', 'MAIN9877', '', 'MO;PULL;SMS;REG', 2000, 0),
(8, 0, '1947', '2012-04-03 15:47:09', '9877', '6281883334443', 5, 'reg anunya', NULL, '', '', '123PULL2000', '', 'sms', 'MAIN9877', '', 'MO;PULL;SMS;REG', 2000, 0),
(9, 8, '1947', '2012-04-03 15:51:49', '9877', '6281883334443', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message>\n<status>0</status>\n<tid>111121015238149919</tid>\n</message>\n', '126SMSPULL3000', '', 'sms', 'MAIN9877', '', 'MT;PULL;SMS;REG', 0, 0),
(10, 8, '1947', '2012-04-03 15:53:36', '9877', '6281883334443', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message>\n<status>0</status>\n<tid>111121015238149919</tid>\n</message>\n', '123SMSPUSH2000', '', 'sms', 'MAIN9877', '', 'MT;PUSH;SMS;REG', 2000, 0),
(11, 8, '2012040315472613334428469783', '2012-04-03 15:53:42', '9877', '6281883334443', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/h4Sl http://m.kiosmobile.com/d/h/tk/h4Sl', 'DELIVERED', 'DELIVERED', '<message>\n<status>0</status>\n<tid>111121015238149919</tid>\n</message>\n', '123WAPPUSH2000', '', 'sms', 'MAIN9877', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(12, 8, '2012040315472613334428469783', '2012-04-03 15:53:42', '9877', '6281883334443', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/h4Sl http://m.kiosmobile.com/d/h/tk/h4Sl', 'DELIVERED', 'DELIVERED', '<message>\n<status>0</status>\n<tid>111121015238149919</tid>\n</message>\n', '123WAPPUSH2000', '', 'sms', 'MAIN9877', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(13, 0, '7519', '2012-04-13 16:34:06', '9877', '6212345', 5, 'reg apa', NULL, '', '', '123PULL2000', '', 'sms', 'MAIN9877', '', 'MO;PULL;SMS;REG', 2000, 0),
(14, 0, '1807', '2012-04-13 14:54:08', '9877', '622i374840', 5, 'tes', NULL, 'DELIVERED', '', '123PULL2000', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 2000, 0),
(15, 0, '4174', '2012-04-13 14:54:19', '9877', '629096069600', 5, 'ure', NULL, 'DELIVERED', '', '123PULL2000', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 2000, 0),
(16, 0, '8311', '2012-04-13 14:54:25', '9877', '626338440', 5, 'youre', NULL, 'DELIVERED', '', '123PULL2000', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 2000, 0),
(17, 0, '4054', '2012-04-13 16:53:46', '9877', '6212345', 5, 'reg apa', NULL, '', '', '123PULL2000', '', 'sms', 'MAIN9877', '', 'MO;PULL;SMS;REG', 2000, 0),
(18, 0, '9186', '2012-04-13 14:54:33', '9877', '6253635829', 5, 'opr', NULL, 'DELIVERED', '', '123PULL2000', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 2000, 0),
(19, 0, '5256', '2012-04-13 16:55:08', '9877', '6212345', 5, 'reg apa', NULL, '', '', '123PULL2000', '', 'sms', 'MAIN9877', '', 'MO;PULL;SMS;REG', 2000, 0),
(20, 0, '9295', '2012-04-13 14:54:38', '9877', '62858545340', 5, 'qerwt', NULL, 'DELIVERED', '', '123PULL2000', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 2000, 0),
(21, 0, '1740', '2012-04-13 14:54:43', '9877', '6200940', 5, 'watyy', NULL, 'DELIVERED', '', '123PULL2000', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 2000, 0),
(22, 14, '1807', '2012-04-13 16:55:53', '9877', '622i374840', 5, 'Error', 'FAILED', 'FAILED', '', '126SMSPULL3000', '', 'sms', 'ERROR', '', 'MT;PULL;SMS;ERROR', 0, 0),
(23, 13, '7519', '2012-04-13 16:55:53', '9877', '6212345', 5, 'selamat datang', 'FAILED', 'FAILED', '', '126SMSPULL3000', '', 'sms', 'MAIN9877', '', 'MT;PULL;SMS;REG', 0, 0),
(24, 15, '4174', '2012-04-13 16:55:53', '9877', '629096069600', 5, 'Error', 'FAILED', 'FAILED', '', '126SMSPULL3000', '', 'sms', 'ERROR', '', 'MT;PULL;SMS;ERROR', 0, 0),
(25, 17, '4054', '2012-04-13 16:55:53', '9877', '6212345', 5, 'anda sudah terdaftar dengan layanan ini', 'FAILED', 'FAILED', '', '126SMSPULL3000', '', 'sms', 'MAIN9877', '', 'MT;PULL;SMS;REG', 0, 0),
(26, 19, '5256', '2012-04-13 16:55:53', '9877', '6212345', 5, 'anda sudah terdaftar dengan layanan ini', 'FAILED', 'FAILED', '', '126SMSPULL3000', '', 'sms', 'MAIN9877', '', 'MT;PULL;SMS;REG', 0, 0),
(27, 16, '8311', '2012-04-13 16:55:53', '9877', '626338440', 5, 'Error', 'FAILED', 'FAILED', '', '126SMSPULL3000', '', 'sms', 'ERROR', '', 'MT;PULL;SMS;ERROR', 0, 0),
(28, 0, '120413064803522', '2012-04-13 15:42:21', '9790', '629254538669341', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(29, 0, '120413064803676', '2012-04-13 16:11:58', '9790', '629254532828073', 5, 'reg game', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(30, 0, '120413064803238', '2012-04-13 15:32:45', '9790', '629254570601385', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(31, 0, '120413065228016', '2012-04-13 18:52:28', '9790', '629254532828073', 5, 'unreg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(32, 0, '120413074829320', '2012-04-13 19:48:29', '9790', '629254538669341', 5, 'unreg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(33, 0, '120413071904832', '2012-04-13 19:19:05', '9790', '629254532828073', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(34, 0, '120413080435601', '2012-04-13 20:04:35', '9790', '629254538669341', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(35, 0, '120413075138837', '2012-04-13 19:51:39', '9790', '629254592724390', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(36, 0, '120413081919857', '2012-04-13 20:19:20', '9790', '629254592724390', 5, 'unreg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(37, 0, '120413082234396', '2012-04-13 20:22:34', '9790', '629254538669341', 5, 'unreg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(38, 0, '120413082640612', '2012-04-13 20:26:40', '9790', '629254538669341', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(39, 0, '120413092341273', '2012-04-13 21:23:41', '9790', '62925455110098', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(40, 0, '120413092610175', '2012-04-13 21:26:10', '9790', '62925455110098', 5, 'unreg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(41, 0, '120413100724191', '2012-04-13 22:07:24', '9790', '62925455110098', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(42, 0, '120413101859471', '2012-04-13 22:18:59', '9790', '62925455110098', 5, 'unreg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(43, 0, '120413102409349', '2012-04-13 22:24:09', '9790', '62925455110098', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(44, 0, '120416100509692', '2012-04-16 10:05:10', '9790', '62925455110098', 5, 'unreg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(45, 0, '120416101614169', '2012-04-16 10:16:14', '9790', '62925455930734', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(46, 0, '120416101928314', '2012-04-16 10:19:28', '9790', '62925455930734', 5, 'unreg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(47, 0, '120416102314638', '2012-04-16 10:23:15', '9790', '62925455930736', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(48, 0, '120416102706263', '2012-04-16 10:27:06', '9790', '629254532828073', 5, 'unreg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(49, 0, '120416102831072', '2012-04-16 10:28:31', '9790', '629254532828073', 5, 'reg konten', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(50, 0, '120416103832331', '2012-04-16 10:38:32', '9790', '62925455930734', 5, 'reg fun', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(51, 0, '120416105312924', '2012-04-16 10:53:13', '9790', '62925455930734', 5, 'unreg fun', NULL, 'DELIVERED', '', '9790SMSMO0', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(52, 51, '120416105312924', '2012-04-16 11:03:01', '9790', '62925455930734', 5, 'Error', 'FAILED', 'FAILED', '', '9790SMSPULL3000', '', 'sms', 'ERROR', '', 'MT;PULL;SMS;ERROR', 0, 0),
(53, 0, '120416105534535', '2012-04-16 10:55:34', '9790', '62925455930734', 5, 'reg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(54, 53, '120416105534535', '2012-04-16 11:05:01', '9790', '62925455930734', 5, 'selamat datang', 'FAILED', 'FAILED', '', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(55, 0, '120416105846644', '2012-04-16 10:58:47', '9790', '62925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(56, 55, '120416105846644', '2012-04-16 11:09:02', '9790', '62925455930734', 5, 'anda sudah terdaftar dengan layanan ini', 'FAILED', 'FAILED', '', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(57, 0, '120416110052669', '2012-04-16 11:00:53', '9790', '62925455930734', 5, 'unreg fun', NULL, 'DELIVERED', '', '9790SMSMO0', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(58, 57, '120416110052669', '2012-04-16 11:11:01', '9790', '62925455930734', 5, 'Error', 'FAILED', 'FAILED', '', '9790SMSPULL3000', '', 'sms', 'ERROR', '', 'MT;PULL;SMS;ERROR', 0, 0),
(59, 0, '120416110546088', '2012-04-16 11:05:46', '9790', '62925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(60, 59, '120416110546088', '2012-04-16 11:16:01', '9790', '62925455930734', 5, 'anda sudah terdaftar dengan layanan ini', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(61, 0, '120416110710211', '2012-04-16 11:07:10', '9790', '62925455930734', 5, 'unreg fun', NULL, 'DELIVERED', '', '9790SMSMO0', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(62, 61, '120416110710211', '2012-04-16 11:17:02', '9790', '62925455930734', 5, 'Error', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9790SMSPULL3000', '', 'sms', 'ERROR', '', 'MT;PULL;SMS;ERROR', 0, 0),
(63, 0, '120416111422090', '2012-04-16 11:14:22', '9790', '62925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(64, 63, '120416111422090', '2012-04-16 11:24:01', '9790', '62925455930734', 5, 'anda sudah terdaftar dengan layanan ini', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(65, 0, '120416111733034', '2012-04-16 11:17:33', '9790', '62925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(66, 65, '120416111733034', '2012-04-16 11:27:01', '9790', '62925455930734', 5, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(67, 0, '120416111918053', '2012-04-16 11:19:18', '9790', '62925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(68, 67, '120416111918053', '2012-04-16 11:29:01', '9790', '62925455930734', 5, 'selamat datang', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(69, 0, '120416114344760', '2012-04-16 11:43:45', '9790', '62925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(70, 69, '120416114344760', '2012-04-16 11:54:01', '9790', '62925455930734', 5, 'terimakasih untuk menggunakan layanan kali', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(71, 0, '120416115233948', '2012-04-16 11:52:34', '9790', '62925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(72, 71, '120416115233948', '2012-04-16 12:02:01', '9790', '62925455930734', 5, 'selamat datang', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(73, 0, '120416120555919', '2012-04-16 12:05:56', '9790', '62925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(74, 73, '120416120555919', '2012-04-16 12:16:01', '9790', '62925455930734', 5, 'terimakasih untuk menggunakan layanan kali', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(75, 0, '120416121101302', '2012-04-16 12:11:01', '9790', '62925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(76, 75, '120416121101302', '2012-04-16 12:21:02', '9790', '62925455930734', 5, 'selamat datang', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(77, 0, '120416121549821', '2012-04-16 12:15:50', '9790', '62925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(78, 77, '120416121549821', '2012-04-16 12:26:01', '9790', '62925455930734', 5, 'terimakasih untuk menggunakan layanan kali', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416121549821</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(79, 0, '120416121723044', '2012-04-16 12:17:23', '9790', '62925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(80, 79, '120416121723044', '2012-04-16 12:27:01', '9790', '62925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416121723044</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(81, 0, '120416122345465', '2012-04-16 12:23:45', '9790', '62925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(82, 0, '120416122429871', '2012-04-16 12:24:30', '9790', '62925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(83, 81, '120416122345465', '2012-04-16 12:34:01', '9790', '62925455930734', 5, 'terimakasih untuk menggunakan layanan kali', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416122345465</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(84, 82, '120416122429871', '2012-04-16 12:34:01', '9790', '62925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416122429871</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(85, 0, '120416011626204', '2012-04-16 13:16:26', '9790', '62925450115551', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(86, 85, '120416011626204', '2012-04-16 13:26:01', '9790', '62925450115551', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416011626204</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(87, 0, '120416030908776', '2012-04-16 15:09:09', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(88, 87, '120416030908776', '2012-04-16 15:19:01', '9790', '925455930734', 5, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416030908776</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(89, 0, '120416031411235', '2012-04-16 15:14:11', '9790', '925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(90, 89, '120416031411235', '2012-04-16 15:24:02', '9790', '925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416031411235</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(91, 0, '120416031642548', '2012-04-16 15:16:42', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(92, 91, '120416031642548', '2012-04-16 15:27:01', '9790', '925455930734', 5, 'terimakasih untuk menggunakan layanan kali', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416031642548</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(93, 0, '120416032821747', '2012-04-16 15:28:22', '9790', '9254533996900', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(94, 93, '120416032821747', '2012-04-16 15:38:01', '9790', '9254533996900', 5, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416032821747</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(95, 0, '120416033236581', '2012-04-16 15:32:36', '9790', '925455930736', 5, 'off', NULL, 'DELIVERED', '', '9790SMSMO0', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(96, 95, '120416033236581', '2012-04-16 15:42:01', '9790', '925455930736', 5, 'Error', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416033236581</tid></message>', '9790SMSPULL3000', '', 'sms', 'ERROR', '', 'MT;PULL;SMS;ERROR', 0, 0),
(97, 0, '120416035343906', '2012-04-16 15:53:44', '9790', '9254533996900', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(98, 97, '120416035343906', '2012-04-16 16:04:01', '9790', '9254533996900', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416035343906</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(99, 0, '120416040119036', '2012-04-16 16:01:19', '9790', '925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(100, 99, '120416040119036', '2012-04-16 16:11:01', '9790', '925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416040119036</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(101, 0, '120416040237341', '2012-04-16 16:02:37', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(102, 101, '120416040237341', '2012-04-16 16:12:01', '9790', '925455930734', 5, 'terimakasih untuk menggunakan layanan kali', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416040237341</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(103, 0, '120416040429867', '2012-04-16 16:04:30', '9790', '925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'FUNN', '', 'MO;PULL;SMS;REG', 0, 0),
(104, 103, '120416040429867', '2012-04-16 16:14:01', '9790', '925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416040429867</tid></message>', '9790SMSPULL3000', '', 'sms', 'FUNN', '', 'MT;PULL;SMS;REG', 0, 0),
(105, 99, '120416040119036', '2012-04-16 16:16:01', '9790', '925455930734', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416040633209</tid></message>', '9790SMSPUSH2000', '', 'sms', 'FUNN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(106, 99, '2012041616110113345674616628', '2012-04-16 16:16:01', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/Xq9u http://m.kiosmobile.com/d/h/tk/Xq9u', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041616110113345674616628</tid></message>', '123WAPPUSH2000', '', 'sms', 'FUNN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(107, 103, '120416040429867', '2012-04-16 16:16:01', '9790', '925455930734', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416040633324</tid></message>', '9790SMSPUSH2000', '', 'sms', 'FUNN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(108, 103, '2012041616140113345676412321', '2012-04-16 16:16:01', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/Eajt http://m.kiosmobile.com/d/h/tk/Eajt', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041616140113345676412321</tid></message>', '123WAPPUSH2000', '', 'sms', 'FUNN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(109, 0, '120416044047207', '2012-04-16 16:40:47', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(110, 109, '120416044047207', '2012-04-16 16:51:01', '9790', '925455930734', 5, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416044047207</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(111, 0, '120416044231514', '2012-04-16 16:42:31', '9790', '925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(112, 111, '120416044231514', '2012-04-16 16:52:01', '9790', '925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416044231514</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(113, 111, '120416044231514', '2012-04-16 16:52:01', '9790', '925455930734', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416044233547</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(114, 111, '2012041616520113345699218534', '2012-04-16 16:52:01', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/pBEl http://m.kiosmobile.com/d/h/tk/pBEl', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041616520113345699218534</tid></message>', '123WAPPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(115, 0, '120416045123554', '2012-04-16 16:51:23', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(116, 115, '120416045123554', '2012-04-16 17:01:01', '9790', '925455930734', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416045123554</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(117, 0, '120416045554992', '2012-04-16 16:55:55', '9790', '925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(118, 117, '120416045554992', '2012-04-16 17:06:01', '9790', '925455930734', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416045633347</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(119, 117, '120416045554992', '2012-04-16 17:06:01', '9790', '925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416045554992</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(120, 117, '2012041617060113345707616891', '2012-04-16 17:06:01', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/5giO http://m.kiosmobile.com/d/h/tk/5giO', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041617060113345707616891</tid></message>', '9790WAPPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(121, 0, '120416050532773', '2012-04-16 17:05:33', '9790', '925450115551', 5, 'unreg', NULL, 'DELIVERED', '', '9790SMSMO0', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(122, 121, '120416050532773', '2012-04-16 17:15:02', '9790', '925450115551', 5, 'Error', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416050532773</tid></message>', '9790SMSPULL3000', '', 'sms', 'ERROR', '', 'MT;PULL;SMS;ERROR', 0, 0),
(123, 0, '120416050603295', '2012-04-16 17:06:03', '9790', '925450115551', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(124, 123, '2012041617160113345713613533', '2012-04-16 17:16:01', '9790', '925450115551', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/IX00 http://m.kiosmobile.com/d/h/tk/IX00', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041617160113345713613533</tid></message>', '9790WAPPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(125, 123, '120416050603295', '2012-04-16 17:16:01', '9790', '925450115551', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416050632976</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(126, 123, '120416050603295', '2012-04-16 17:16:01', '9790', '925450115551', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416050603295</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(127, 0, '120416051612785', '2012-04-16 17:16:13', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(128, 127, '120416051612785', '2012-04-16 17:26:01', '9790', '925455930734', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416051612785</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(129, 0, '120416051710377', '2012-04-16 17:17:10', '9790', '925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(130, 129, '120416051710377', '2012-04-16 17:27:01', '9790', '925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416051710377</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(131, 129, '2012041617270113345720213916', '2012-04-16 17:27:01', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/9aAy http://m.kiosmobile.com/d/h/tk/9aAy', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041617270113345720213916</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(132, 129, '120416051710377', '2012-04-16 17:27:01', '9790', '925455930734', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416051733034</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(133, 0, '120416063616641', '2012-04-16 18:36:17', '9790', '925455930734', 5, 'fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(134, 133, '120416063616641', '2012-04-16 18:46:01', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/Fyc6 http://m.kiosmobile.com/d/h/tk/Fyc6', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416063616641</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(135, 0, '120416070356079', '2012-04-16 19:03:56', '9790', '925455930734', 5, 'fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(136, 135, '120416070356079', '2012-04-16 19:14:02', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/72vP http://m.kiosmobile.com/d/h/tk/72vP', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416070356079</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(137, 0, '120416073036571', '2012-04-16 19:30:36', '9790', '925455110098', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(138, 137, '120416073036571', '2012-04-16 19:40:02', '9790', '925455110098', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416073033676</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(139, 137, '120416073036571', '2012-04-16 19:40:02', '9790', '925455110098', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416073036571</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(140, 137, '2012041619400213345800022003', '2012-04-16 19:40:02', '9790', '925455110098', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/IxMj http://m.kiosmobile.com/d/h/tk/IxMj', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041619400213345800022003</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(141, 0, '120416073352797', '2012-04-16 19:33:53', '9790', '925455110098', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(142, 0, '120416073429090', '2012-04-16 19:34:29', '9790', '925455110098', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(143, 141, '120416073352797', '2012-04-16 19:44:02', '9790', '925455110098', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416073352797</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(144, 142, '120416073429090', '2012-04-16 19:44:02', '9790', '925455110098', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416073433450</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(145, 142, '2012041619440113345802419584', '2012-04-16 19:44:02', '9790', '925455110098', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/Ce1J http://m.kiosmobile.com/d/h/tk/Ce1J', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041619440113345802419584</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(146, 142, '120416073429090', '2012-04-16 19:44:02', '9790', '925455110098', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416073429090</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(147, 0, '120416073536537', '2012-04-16 19:35:36', '9790', '925455110098', 5, 'fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(148, 147, '120416073536537', '2012-04-16 19:45:01', '9790', '925455110098', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/EiUF http://m.kiosmobile.com/d/h/tk/EiUF', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416073536537</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(149, 0, '120416073858469', '2012-04-16 19:38:58', '9790', '925455110098', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(150, 149, '120416073858469', '2012-04-16 19:49:02', '9790', '925455110098', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416073858469</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(151, 0, '120416074218610', '2012-04-16 19:42:18', '9790', '925455110098', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(152, 151, '2012041619520113345807215366', '2012-04-16 19:52:01', '9790', '925455110098', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/zNw3 http://m.kiosmobile.com/d/h/tk/zNw3', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041619520113345807215366</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(153, 151, '120416074218610', '2012-04-16 19:52:01', '9790', '925455110098', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416074233023</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(154, 151, '120416074218610', '2012-04-16 19:52:01', '9790', '925455110098', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416074218610</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(155, 0, '120416074533127', '2012-04-16 19:45:33', '9790', '925455110098', 5, 'fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(156, 155, '120416074533127', '2012-04-16 19:55:02', '9790', '925455110098', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/e8cG http://m.kiosmobile.com/d/h/tk/e8cG', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416074533127</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(157, 0, '120416074658613', '2012-04-16 19:46:58', '9790', '925455110098', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(158, 157, '120416074658613', '2012-04-16 19:57:01', '9790', '925455110098', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120416074658613</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(159, 0, '120417114532165', '2012-04-17 11:45:32', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(160, 159, '120417114532165', '2012-04-17 11:55:02', '9790', '925455930734', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417114532165</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(161, 0, '120417022401952', '2011-07-19 02:24:52', '9790', '9254532828073', 5, 'unreg game', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(162, 161, '120417022401952', '2012-04-17 14:34:02', '9790', '9254532828073', 5, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417022401952</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(163, 0, '120417022503320', '2011-07-19 02:25:52', '9790', '9254532828073', 5, 'reg game', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(164, 163, '120417022503320', '2012-04-17 14:35:02', '9790', '9254532828073', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417022532307</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(165, 163, '2012041714350113346481019592', '2012-04-17 14:35:02', '9790', '9254532828073', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/FFdl http://m.kiosmobile.com/d/h/tk/FFdl', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041714350113346481019592</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(166, 163, '120417022503320', '2012-04-17 14:35:02', '9790', '9254532828073', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417022503320</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(167, 0, '120417023539363', '2012-04-17 14:35:39', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(168, 167, '120417023539363', '2012-04-17 14:46:01', '9790', '925455930734', 5, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417023539363</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(169, 0, '120417023851217', '2012-04-17 14:38:51', '9790', '925455930734', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(170, 169, '2012041714490113346489418365', '2012-04-17 14:49:01', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/2YRd http://m.kiosmobile.com/d/h/tk/2YRd', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041714490113346489418365</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(171, 169, '120417023851217', '2012-04-17 14:49:01', '9790', '925455930734', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417023932172</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(172, 169, '120417023851217', '2012-04-17 14:49:01', '9790', '925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417023851217</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(173, 0, '120417040946023', '2011-07-19 04:10:36', '9790', '925455930734', 5, 'fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(174, 173, '120417040946023', '2012-04-17 16:20:02', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/909U http://m.kiosmobile.com/d/h/tk/909U', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417040946023</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(175, 0, '120417042132958', '2011-07-19 04:22:23', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(176, 175, '120417042132958', '2012-04-17 16:31:02', '9790', '925455930734', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417042132958</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(177, 0, '120417042618084', '2011-07-19 04:27:08', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(178, 177, '120417042618084', '2012-04-17 16:36:01', '9790', '925455930734', 5, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417042618084</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(179, 0, '120417052341978', '2011-07-19 05:24:32', '9790', '925455930734', 5, 'fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(180, 179, '120417052341978', '2012-04-17 17:34:02', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/RoJG http://m.kiosmobile.com/d/h/tk/RoJG', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417052341978</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(181, 0, '120417080001909', '2012-04-17 19:58:27', '9790', '925455930795', 5, 'reg fun3', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(182, 181, '2012041720100213346682021873', '2012-04-17 20:10:02', '9790', '925455930795', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/d7RE http://m.kiosmobile.com/d/h/tk/d7RE', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041720100213346682021873</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(183, 181, '120417080001909', '2012-04-17 20:10:02', '9790', '925455930795', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417080001909</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(184, 181, '120417080001909', '2012-04-17 20:10:02', '9790', '925455930795', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417075905725</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(185, 0, '120417081830961', '2012-04-17 20:16:57', '9790', '9254571055793', 5, 'reg fun3', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(186, 185, '120417081830961', '2012-04-17 20:28:02', '9790', '9254571055793', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417081830961</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(187, 185, '2012041720280213346692820652', '2012-04-17 20:28:02', '9790', '9254571055793', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/TQ1v http://m.kiosmobile.com/d/h/tk/TQ1v', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041720280213346692820652</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(188, 185, '120417081830961', '2012-04-17 20:28:02', '9790', '9254571055793', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120417081705517</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(189, 0, '120418094648233', '2011-07-19 21:47:38', '9790', '9254532828073', 5, 'fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(190, 189, '120418094648233', '2012-04-18 09:57:02', '9790', '9254532828073', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/xkbI http://m.kiosmobile.com/d/h/tk/xkbI', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418094648233</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(191, 0, '120418112914191', '2011-07-19 23:30:04', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(192, 191, '120418112914191', '2012-04-18 11:39:02', '9790', '925455930734', 5, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418112914191</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(193, 0, '120418113028992', '2012-04-18 11:32:20', '9790', '925455110098', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(194, 193, '2012041811400113347240017074', '2012-04-18 11:40:01', '9790', '925455110098', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/P96f http://m.kiosmobile.com/d/h/tk/P96f', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041811400113347240017074</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(195, 193, '120418113028992', '2012-04-18 11:40:01', '9790', '925455110098', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418112904165</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(196, 193, '120418113028992', '2012-04-18 11:40:01', '9790', '925455110098', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418113028992</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(197, 0, '120418113207155', '2011-07-19 23:32:57', '9790', '925455110098', 5, 'fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(198, 197, '120418113207155', '2012-04-18 11:42:01', '9790', '925455110098', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/nFol http://m.kiosmobile.com/d/h/tk/nFol', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418113207155</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(199, 0, '120418113424553', '2012-04-18 11:32:50', '9790', '925455930734', 5, 'reg fun3', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(200, 199, '2012041811440113347242419926', '2012-04-18 11:44:02', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/M4px http://m.kiosmobile.com/d/h/tk/M4px', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041811440113347242419926</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(201, 199, '120418113424553', '2012-04-18 11:44:02', '9790', '925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418113424553</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(202, 199, '120418113424553', '2012-04-18 11:44:02', '9790', '925455930734', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418113304386</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(203, 0, '120418113440597', '2012-04-18 11:36:32', '9790', '925455930736', 5, 'reg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(204, 203, '120418113440597', '2012-04-18 11:45:02', '9790', '925455930736', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418113440597</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(205, 203, '120418113440597', '2012-04-18 11:45:02', '9790', '925455930736', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418113404414</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(206, 203, '2012041811450113347243019971', '2012-04-18 11:45:02', '9790', '925455930736', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/x0Ch http://m.kiosmobile.com/d/h/tk/x0Ch', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041811450113347243019971</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(207, 0, '120418114056301', '2011-07-19 23:41:46', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(208, 207, '120418114056301', '2012-04-18 11:51:01', '9790', '925455930734', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418114056301</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(209, 0, '120418114343119', '2012-04-18 11:45:34', '9790', '925455110098', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(210, 209, '120418114343119', '2012-04-18 11:54:01', '9790', '925455110098', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418114343119</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(211, 0, '120418114630274', '2012-04-18 11:44:56', '9790', '925455930734', 5, 'reg fun3', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(212, 211, '120418114630274', '2012-04-18 11:56:02', '9790', '925455930734', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418114504507</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(213, 211, '120418114630274', '2012-04-18 11:56:02', '9790', '925455930734', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418114630274</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(214, 211, '2012041811560213347249621059', '2012-04-18 11:56:02', '9790', '925455930734', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/ZU4U http://m.kiosmobile.com/d/h/tk/ZU4U', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041811560213347249621059</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0);
INSERT INTO `tbl_msgtransact` (`ID`, `IN_REPLY_TO`, `MSGINDEX`, `MSGTIMESTAMP`, `ADN`, `MSISDN`, `OPERATORID`, `MSGDATA`, `MSGLASTSTATUS`, `MSGSTATUS`, `CLOSEREASON`, `SERVICEID`, `MEDIA`, `CHANNEL`, `SERVICE`, `PARTNER`, `SUBJECT`, `PRICE`, `ISR`) VALUES
(215, 0, '120418034205453', '2011-07-20 03:42:56', '9790', '9254570601385', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(216, 215, '120418034205453', '2012-04-18 15:52:01', '9790', '9254570601385', 5, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418034205453</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(217, 0, '120418043228648', '2011-07-20 04:33:19', '9790', '925455930795', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(218, 217, '120418043228648', '2012-04-18 16:42:01', '9790', '925455930795', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418043228648</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(219, 0, '120418043326489', '2012-04-18 16:35:19', '9790', '925455930795', 5, 'reg  fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(220, 219, '120418043326489', '2012-04-18 16:43:01', '9790', '925455930795', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418043203684</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(221, 219, '120418043326489', '2012-04-18 16:43:01', '9790', '925455930795', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/qxwh http://m.kiosmobile.com/d/h/tk/qxwh', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418043326489</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(222, 219, '120418043326489', '2012-04-18 16:43:01', '9790', '925455930795', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418043326489</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(223, 0, '120418074424867', '2012-04-18 19:46:17', '9790', '925455930734', 5, 'unreg fun', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(224, 223, '120418074424867', '2012-04-18 19:54:01', '9790', '925455930734', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120418074424867</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(225, 0, '120419023652115', '2012-04-19 14:36:52', '9790', '925455551296', 5, 'reg konten', NULL, 'DELIVERED', '', '9790SMSMO0', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(226, 225, '120419023652115', '2012-04-19 14:48:02', '9790', '925455551296', 5, 'Error', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419023652115</tid></message>', '9790SMSPULL3000', '', 'sms', 'ERROR', '', 'MT;PULL;SMS;ERROR', 0, 0),
(227, 0, '120419024928264', '2012-04-19 14:49:28', '9790', '9254571055793', 5, 'reg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(228, 227, '120419024928264', '2012-04-19 15:00:02', '9790', '9254571055793', 5, 'anda sudah terdaftar dengan layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419024928264</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(229, 0, '120419025006069', '2012-04-19 14:50:06', '9790', '9254571055793', 5, 'unreg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(230, 229, '120419025006069', '2012-04-19 15:01:02', '9790', '9254571055793', 5, 'terimakasih untuk menggunakan layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419025006069</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(231, 0, '120419025219976', '2012-04-19 14:52:19', '9790', '925455551296', 5, 'reg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;REG', 0, 0),
(232, 231, '120419025219976', '2012-04-19 15:03:02', '9790', '925455551296', 5, 'selamat datang', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419025219976</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;REG', 0, 0),
(233, 231, '120419025219976', '2012-04-19 15:03:02', '9790', '925455551296', 5, 'klik link untuk download gratis. http://m.kiosmobile.com/d/h/tk/rpQg http://m.kiosmobile.com/d/h/tk/rpQg', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419025219976</tid></message>', '9790WAPPUSHPULL2000', '', 'sms', 'DFJIFUN', '', 'MT;WAPPUSH;SMS;REG', 2000, 0),
(234, 231, '120419025219976', '2012-04-19 15:03:02', '9790', '925455551296', 5, 'dapatkan content menarik hanya disini.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419025229535</tid></message>', '9790SMSPUSH2000', '', 'sms', 'DFJIFUN', '', 'MT;PUSH;SMS;REG', 2000, 0),
(235, 0, '120419035025012', '2012-04-19 15:50:25', '9790', '9254571055793', 1, 'reg konten', NULL, '', '', '', '', 'sms', 'KONTEN', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(236, 0, '120419035417923', '2012-04-19 15:54:17', '9790', '9254538669341', 1, 'unreg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(237, 236, '120419035417923', '2012-04-19 16:05:01', '9790', '9254538669341', 1, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419035417923</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(238, 0, '120419035456831', '2012-04-19 15:54:56', '9790', '9254538669341', 1, 'reg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'KONTEN', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(239, 0, '120419035635539', '2012-04-19 15:56:35', '9790', '9254538669341', 1, 'unreg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(240, 239, '120419035635539', '2012-04-19 16:08:01', '9790', '9254538669341', 1, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419035635539</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(241, 0, '120419035816351', '2012-04-19 15:58:16', '9790', '9254538669341', 1, 'reg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'KONTEN', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(242, 0, '120419040600999', '2012-04-19 16:06:01', '9790', '9254538669341', 1, 'unreg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIFUN', '', 'MO;PULL;SMS;UNREG', 0, 0),
(243, 242, '120419040600999', '2012-04-19 16:17:01', '9790', '9254538669341', 1, 'ketik reg untuk masuk layanan ini', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419040600999</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIFUN', '', 'MT;PULL;SMS;UNREG', 0, 0),
(244, 0, '120419041609264', '2012-04-19 16:16:09', '9790', '9254538669341', 1, 'reg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'KONTEN', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(245, 244, '2012041916270113348276216363', '2012-04-19 16:27:01', '9790', '9254538669341', 1, 'anda dapat mobil', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041916270113348276216363</tid></message>', '9790SMSPULL3000', '', 'sms', 'KONTEN', '', 'MT;PULL;SMS;TEXT', 2000, 0),
(246, 0, '120419042532807', '2012-04-19 16:24:18', '9790', '9254571055793', 1, 'unreg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'KONTEN', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(247, 0, '120419042532973', '2012-04-19 16:25:06', '9790', '9254571055793', 1, 'reg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'KONTEN', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(248, 246, '2012041916370113348282215553', '2012-04-19 16:37:01', '9790', '9254571055793', 1, 'Terimakasih atas partisipasinya dalam layanan KONTEN. Anda\ntidak akan menerima info lagi.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041916370113348282215553</tid></message>', '9790SMSPULL3000', '', 'sms', 'KONTEN', '', 'MT;PULL;SMS;TEXT', 0, 0),
(249, 247, '2012041916370113348282216054', '2012-04-19 16:37:01', '9790', '9254571055793', 1, 'Hai, kamu dpt bonus konten kalkulator cinta + aplikasi diet Palestina, akn trm info brita hiburan, 1 sms/hr,Rp 2rb/sms. utk berhenti:UNREG', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041916370113348282216054</tid></message>', '9790SMSPULL3000', '', 'sms', 'KONTEN', '', 'MT;PULL;SMS;TEXT', 2000, 0),
(250, 0, '120419043444360', '2012-04-19 16:34:44', '9790', '9254538669341', 1, 'konten', NULL, 'DELIVERED', '', '9790SMSMO0', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(251, 250, '120419043444360', '2012-04-19 16:46:01', '9790', '9254538669341', 1, 'Error', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419043444360</tid></message>', '9790SMSPULL3000', '', 'sms', 'ERROR', '', 'MT;PULL;SMS;ERROR', 0, 0),
(252, 0, '120419044637617', '2012-04-19 16:46:37', '9790', '925455551296', 1, 'reg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIKONT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(253, 252, '2012041916580113348294815366', '2012-04-19 16:58:01', '9790', '925455551296', 1, 'Hai, kamu dpt bonus konten kalkulator cinta + aplikasi diet Palestina, akn trm info brita hiburan, 1 sms/hr,Rp 2rb/sms. utk berhenti:UNREG', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>2012041916580113348294815366</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIKONT', '', 'MT;PULL;SMS;TEXT', 2000, 0),
(254, 0, '120419050353196', '2012-04-19 17:03:53', '9790', '9254538669341', 1, 'unreg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIKONT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(255, 254, '120419050353196', '2012-04-19 17:15:02', '9790', '9254538669341', 1, 'Anda tidak terdaftar di layanan KONTEN', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419050353196</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIKONT', '', 'MT;PULL;SMS;TEXT', 0, 0),
(256, 0, '120419050457988', '2012-04-19 17:04:58', '9790', '9254538669341', 1, 'reg konten', NULL, '', '', '9790SMSMO0', '', 'sms', 'DFJIKONT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(257, 256, '120419050457988', '2012-04-19 17:16:01', '9790', '9254538669341', 1, 'Hai, kamu dpt bonus konten kalkulator cinta + aplikasi diet Palestina, akn trm info brita hiburan, 1 sms/hr,Rp 2rb/sms. utk berhenti:UNREG', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120419050457988</tid></message>', '9790SMSPULL3000', '', 'sms', 'DFJIKONT', '', 'MT;PULL;SMS;TEXT', 2000, 0),
(258, 0, '120420062900384', '2012-04-20 18:29:00', '168', '9254570601385', 1, 'reg tsyt', NULL, '', '', '9790SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(259, 0, '120420062900384', '2012-04-20 18:40:02', '168', '9254570601385', 1, 'push yatta-200', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420062928424</tid></message>', '9790SMSPUSH2000', '', 'sms', 'KLBJTSYT', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(260, 258, '120420062900384', '2012-04-20 18:40:02', '168', '9254570601385', 1, 'welcome yatta-test', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420062900384</tid></message>', '9790SMSPULL3000', '', 'sms', 'KLBJTSYT', '', 'MT;PULL;SMS;TEXT', 0, 0),
(261, 0, '120420064522075', '2012-04-20 18:45:22', '168', '9254570601385', 1, 'unreg tsyt', NULL, '', '', '168SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(262, 0, '120420070433028', '2012-04-20 19:04:33', '168', '9254533996900', 1, 'reg tsyt', NULL, '', '', '168SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(263, 0, '120420070433028', '2012-04-20 19:16:02', '168', '9254533996900', 1, 'yatta-push-2000', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420070528158</tid></message>', '168SMSPUSH2000', '', 'sms', 'KLBJTSYT', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(264, 0, '120420071212495', '2012-04-20 19:12:12', '168', '9254533996900', 1, 'tsyt pull', NULL, '', '', '168SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(265, 264, '120420071212495', '2012-04-20 19:23:01', '168', '9254533996900', 1, 'pull yatta 350', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420071212495</tid></message>', '168SMSPULL350', '', 'sms', 'KLBJTSYT', '', 'MT;PULL;SMS;TEXT', 350, 0),
(266, 0, '120420071434183', '2012-04-20 19:14:34', '168', '9254533996900', 1, 'unreg tsyt', NULL, '', '', '168SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(267, 0, '120420071851156', '2012-04-20 19:18:51', '168', '9254533996900', 1, 'reg tsyt', NULL, '', '', '168SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(268, 267, '120420071851156', '2012-04-20 19:30:02', '168', '9254533996900', 1, 'welcome yatta-test', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420071851156</tid></message>', '168SMSPULL350', '', 'sms', 'KLBJTSYT', '', 'MT;PULL;SMS;TEXT', 350, 0),
(269, 0, '120420071851156', '2012-04-20 19:30:02', '168', '9254533996900', 1, 'push-yatta-2000', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420071927972</tid></message>', '168SMSPUSH2000', '', 'sms', 'KLBJTSYT', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(270, 0, '120420072528316', '2012-04-20 19:25:28', '168', '9254533996900', 1, 'unreg tsyt', NULL, '', '', '168SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(271, 270, '120420072528316', '2012-04-20 19:37:01', '168', '9254533996900', 1, 'Anda telah non-aktif di layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420072528316</tid></message>', '168SMSPULL350', '', 'sms', 'KLBJTSYT', '', 'MT;PULL;SMS;TEXT', 350, 0),
(272, 0, '120420072750756', '2012-04-20 19:27:50', '168', '9254533996900', 1, 'reg tsyt', NULL, '', '', '168SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(273, 272, '120420072750756', '2012-04-20 19:39:01', '168', '9254533996900', 1, 'welcome yatta-test', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420072750756</tid></message>', '168SMSPULL350', '', 'sms', 'KLBJTSYT', '', 'MT;PULL;SMS;TEXT', 350, 0),
(274, 0, '120420072750756', '2012-04-20 19:39:02', '168', '9254533996900', 1, 'push-yatta-2000', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420072827896</tid></message>', '168SMSPUSH2000', '', 'sms', 'KLBJTSYT', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(275, 0, '120420074526380', '2012-04-20 19:45:26', '168', '9254533996900', 1, 'unreg tsyt', NULL, '', '', '168SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(276, 275, '120420074526380', '2012-04-20 19:56:01', '168', '9254533996900', 1, 'Anda telah non-aktif di layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420074526380</tid></message>', '168SMSPULL350', '', 'sms', 'KLBJTSYT', '', 'MT;PULL;SMS;TEXT', 350, 0),
(277, 0, '120420075013798', '2012-04-20 19:50:13', '168', '9254533996900', 1, 'reg tsyt', NULL, '', '', '168SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(278, 277, '120420075013798', '2012-04-20 20:01:03', '168', '9254533996900', 1, 'welcome yatta-test', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420075013798</tid></message>', '168SMSPULL350', '', 'sms', 'KLBJTSYT', '', 'MT;PULL;SMS;TEXT', 350, 0),
(279, 0, '120420075013798', '2012-04-20 20:01:03', '168', '9254533996900', 1, 'push yatta 500', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420075029400</tid></message>', '168SMSPUSH500', '', 'sms', 'KLBJTSYT', '', 'MT;PUSH;SMS;TEXT', 500, 0),
(280, 0, '120420075145907', '2012-04-20 19:51:45', '168', '9254533996900', 1, 'unreg tsyt', NULL, '', '', '168SMSMO0', '', 'sms', 'KLBJTSYT', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(281, 280, '120420075145907', '2012-04-20 20:03:01', '168', '9254533996900', 1, 'Anda telah non-aktif di layanan kami', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120420075145907</tid></message>', '168SMSPULL350', '', 'sms', 'KLBJTSYT', '', 'MT;PULL;SMS;TEXT', 350, 0),
(282, 0, '120420075426370', '2012-04-20 19:54:26', '168', '9254574638135', 1, 'testwp', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(283, 0, '120420075741907', '2012-04-20 19:57:41', '168', '9254574638135', 1, 'testwp', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(284, 0, '120420083531929', '2012-04-20 20:35:31', '168', '9254574638135', 1, 'stop', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(285, 0, '120420083549836', '2012-04-20 20:35:49', '168', '9254574638135', 1, 'stop', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(286, 0, '120421061324543', '2012-04-21 06:13:24', '168', '9254571619738', 1, 'unsub', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(287, 0, '120726843045808', '2012-07-26 13:24:37', '9879', '9254570601385', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(288, 0, '120726314891584', '2012-07-26 13:25:01', '9879', '9254570601385', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(289, 0, '120726314891584', '2012-07-26 13:36:02', '9879', '9254570601385', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'FAILED', '<message><status>-9</status></message>', '168SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(290, 287, '120726843045808', '2012-07-26 13:36:02', '9879', '9254570601385', 1, '', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(291, 288, '120726314891584', '2012-07-26 13:36:02', '9879', '9254570601385', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726314891584</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(292, 0, '120726594670028', '2012-07-26 13:30:05', '9879', '9254570601385', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(293, 292, '120726594670028', '2012-07-26 13:43:01', '9879', '9254570601385', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726594670028</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(294, 0, '120726354116264', '2012-07-26 13:54:14', '9879', '9254570618858', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(295, 294, '120726354116264', '2012-07-26 14:06:01', '9879', '9254570618858', 1, '', 'DELIVERED', 'FAILED', '<message><status>-1</status></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(296, 0, '120726783304990', '2012-07-26 14:13:21', '9879', '9254570618858', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(297, 0, '120726783304990', '2012-07-26 14:25:01', '9879', '9254570618858', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726310687662</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(298, 296, '120726783304990', '2012-07-26 14:25:01', '9879', '9254570618858', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726783304990</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(299, 0, '120726271655597', '2012-07-26 14:15:15', '9879', '9254570601385', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(300, 299, '120726271655597', '2012-07-26 14:27:01', '9879', '9254570601385', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726271655597</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(301, 0, '120726271655597', '2012-07-26 14:27:01', '9879', '9254570601385', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726452569988</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(302, 0, '120726373688909', '2012-07-26 14:14:55', '9879', '9254570618858', 1, 'adzan pull', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(303, 302, '120726373688909', '2012-07-26 14:28:01', '9879', '9254570618858', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, \nklik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726373688909</tid></message>', '9879SMSPULL1000', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 1000, 0),
(304, 0, '120726357338518', '2012-07-26 14:16:50', '9879', '9254570601385', 1, 'adzan', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(305, 0, '120726254728201', '2012-07-26 14:16:55', '9879', '9254570601385', 1, 'adzan pull', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(306, 305, '120726254728201', '2012-07-26 14:30:01', '9879', '9254570601385', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, \nklik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726254728201</tid></message>', '9879SMSPULL1000', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 1000, 0),
(307, 0, '120726563655477', '2012-07-26 14:17:34', '9879', '9254570618858', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(308, 307, '120726563655477', '2012-07-26 14:31:01', '9879', '9254570618858', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726563655477</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(309, 0, '120726815953780', '2012-07-26 14:27:18', '9879', '9254570601385', 1, 'unreg', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(310, 0, '120726170741857', '2012-07-26 14:28:06', '9879', '9254570601385', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(311, 0, '120726170741857', '2012-07-26 14:41:01', '9879', '9254570601385', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726408953698</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(312, 0, '120726345349561', '2012-07-26 14:49:58', '9879', '9254573501052', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(313, 312, '120726345349561', '2012-07-26 15:03:01', '9879', '9254573501052', 1, 'Anda tidak terdaftar. Reg ADZAN ke 9879 untuk mendaftar', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726345349561</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(314, 0, '120726632796312', '2012-07-26 14:53:38', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(315, 314, '120726632796312', '2012-07-26 15:05:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726632796312</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(316, 0, '120726632796312', '2012-07-26 15:05:01', '9879', '9254573501052', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726592692210</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(317, 0, '12072681102298', '2012-07-26 14:53:34', '9879', '9254573501052', 1, 'adzan', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(318, 0, '120726391636489', '2012-07-26 14:56:42', '9879', '9254573501052', 1, 'adzan', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(319, 0, '12072656775143', '2012-07-26 14:58:36', '9879', '9254573501052', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(320, 319, '12072656775143', '2012-07-26 15:12:01', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12072656775143</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(321, 0, '120726836438674', '2012-07-26 16:16:00', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(322, 0, '120726836438674', '2012-07-26 16:27:02', '9879', '9254573501052', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726415124930</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(323, 321, '120726836438674', '2012-07-26 16:27:02', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726836438674</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(324, 0, '120726163367538', '2012-07-26 16:21:34', '9879', '9254573501052', 1, 'adzan', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(325, 0, '120726487732103', '2012-07-26 16:22:37', '9879', '9254573501052', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(326, 325, '120726487732103', '2012-07-26 16:35:01', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120726487732103</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(327, 0, '120728912210402', '2012-07-28 05:16:46', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(328, 0, '120728912210402', '2012-07-28 05:28:01', '9879', '9254573501052', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120728778839175</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(329, 327, '120728912210402', '2012-07-28 05:28:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120728912210402</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(330, 0, '120728835012893', '2012-07-28 05:19:10', '9879', '9254573501052', 1, 'adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(331, 330, '120728835012893', '2012-07-28 05:31:01', '9879', '9254573501052', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, \nklik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120728835012893</tid></message>', '9879SMSPULL1000', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 1000, 0),
(332, 0, '120728269194468', '2012-07-28 05:18:43', '9879', '9254573501052', 1, 'adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(333, 332, '120728269194468', '2012-07-28 05:32:01', '9879', '9254573501052', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, \nklik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120728269194468</tid></message>', '9879SMSPULL1000', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 1000, 0),
(334, 0, '120728378494462', '2012-07-28 05:21:36', '9879', '9254573501052', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(335, 334, '120728378494462', '2012-07-28 05:33:01', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120728378494462</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(336, 0, '120729162226588', '2012-07-29 12:22:55', '9879', '9254505605040', 1, 'unreg', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(337, 0, '12073141730634', '2012-07-31 13:43:50', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(338, 337, '12073141730634', '2012-07-31 13:57:02', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12073141730634</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(339, 0, '12073141730634', '2012-07-31 13:57:02', '9879', '9254573501052', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120731358932881</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(340, 0, '120731513485318', '2012-07-31 15:09:18', '9879', '9254573501052', 1, 'adan', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(341, 0, '2012073117194113437299813404', '2012-07-31 17:39:01', '9879', '9254570601385', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, dan perbaikilah bagiku duniaku yang padanya Engkau jadikan penghidupanku', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120731841383499</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(342, 0, '120731666417008', '2012-07-31 17:36:50', '9879', '9254573501052', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(343, 342, '120731666417008', '2012-07-31 17:50:02', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120731666417008</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(344, 0, '120731535454319', '2012-07-31 17:38:41', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(345, 344, '120731535454319', '2012-07-31 17:52:02', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120731535454319</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(346, 0, '120731535454319', '2012-07-31 17:52:02', '9879', '9254573501052', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120731660088795</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(347, 0, '2012073117535413437320342855', '2012-07-31 17:55:01', '9879', '9254570601385', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, dan perbaikilah bagiku duniaku yang padanya Engkau jadikan penghidupanku', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120731791099881</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(348, 0, '2012080110430213437925822837', '2012-08-01 10:44:01', '9879', '9254570601385', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, dan perbaikilah bagiku duniaku yang padanya Engkau jadikan penghidupanku', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801995202235</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(349, 0, '2012080110430213437925822873', '2012-08-01 10:44:01', '9879', '9254573501052', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, dan perbaikilah bagiku duniaku yang padanya Engkau jadikan penghidupanku', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801358939983</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(350, 0, '2012080110500113437930016371', '2012-08-01 10:51:02', '9879', '9254570601385', 1, 'test', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801686854706</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(351, 0, '2012080110500113437930016065', '2012-08-01 10:51:02', '9879', '9254570601385', 1, 'ADZAN: Ya Allah ya Rab, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, dan perbaikilah bagiku duniaku yang padanya Engkau jadikan penghidupanku', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080184289950</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(352, 0, '2012080110500113437930016189', '2012-08-01 10:51:02', '9879', '9254573501052', 1, 'ADZAN: Ya Allah ya Rab, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, dan perbaikilah bagiku duniaku yang padanya Engkau jadikan penghidupanku', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801233966748</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(353, 0, '2012080110510113437930617727', '2012-08-01 10:52:02', '9879', '9254570601385', 1, 'ADZAN: Ya Allah ya Rab, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, dan perbaikilah bagiku duniaku yang padanya Engkau jadikan penghidupanku', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801197939362</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(354, 0, '2012080110500113437930016396', '2012-08-01 10:52:02', '9879', '9254573501052', 1, 'test', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801917044409</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(355, 0, '2012080110510113437930617763', '2012-08-01 10:52:02', '9879', '9254573501052', 1, 'ADZAN: Ya Allah ya Rab, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, dan perbaikilah bagiku duniaku yang padanya Engkau jadikan penghidupanku', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801755163416</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(356, 0, '120801147552028', '2012-08-01 11:13:11', '9879', '9254570601385', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(357, 0, '120801147552028', '2012-08-01 11:26:02', '9879', '9254570601385', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080185362182</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(358, 0, '120801482378609', '2012-08-01 11:21:29', '9879', '9254570601385', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(359, 358, '120801482378609', '2012-08-01 11:33:01', '9879', '9254570601385', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801482378609</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(360, 0, '120801773681847', '2012-08-01 11:23:09', '9879', '9254570601385', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(361, 360, '120801773681847', '2012-08-01 11:35:01', '9879', '9254570601385', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801773681847</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(362, 0, '120801773681847', '2012-08-01 11:35:01', '9879', '9254570601385', 1, 'Segala puji bagi Allah yang menghidupkan kami setelah mematikan kami. Kepada-Nya-lah kami akan kembali (HR. Bukhari) klik disini http://m.marimain.com/mic/adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801726540430</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(363, 0, '2012080110430213437925822837', '2012-08-01 11:39:01', '9879', '9254570601385', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, dan perbaikilah bagiku duniaku yang padanya Engkau jadikan penghidupanku', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801152703245</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(364, 0, '2012080117380213438174820553', '2012-08-01 17:39:01', '9879', '9254573501052', 1, 'test', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801119318086</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(365, 0, '2012080117380213438174820352', '2012-08-01 17:39:01', '9879', '9254573501052', 1, 'ADZAN: Ya Allah ya Rab, perbaikilah bagiku agamaku yang menjadi pegangan urusanku, dan perbaikilah bagiku duniaku yang padanya Engkau jadikan penghidupanku', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120801487859757</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(366, 0, '120801291227861', '2012-08-01 21:11:55', '9879', '9254542943010', 1, 'stop', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(367, 0, '2012080207000113438656022341', '2012-08-02 07:01:04', '9879', '9254573501052', 1, '2AgstDzr:12:01,Ashr:15:23,Mgb:17:56,Isya:19:09,3AgstSbh:04:45(wib),seorang isteri mnt ijin suaminya utk pergi ke masjid mk jgnlah sg suami mlrnganya. (HR. Bukha', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120802805112558</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(368, 0, '2012080207000213438656023395', '2012-08-02 07:01:04', '9879', '9254570601385', 1, '2AgstDzr:12:01,Ashr:15:23,Mgb:17:56,Isya:19:09,3AgstSbh:04:45(wib),seorang isteri mnt ijin suaminya utk pergi ke masjid mk jgnlah sg suami mlrnganya. (HR. Bukha', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120802988424516</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(369, 0, '12080210325354', '2012-08-02 10:45:17', '9879', '9254573501052', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(370, 369, '12080210325354', '2012-08-02 10:58:02', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080210325354</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(371, 0, '12080263800297', '2012-08-02 10:50:19', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(372, 371, '12080263800297', '2012-08-02 11:02:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080263800297</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(373, 0, '12080272654465', '2012-08-02 12:08:31', '9879', '9254573501052', 1, 'reg bonus', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(374, 0, '120802919431279', '2012-08-02 15:17:34', '9879', '9254573501052', 1, 'unreg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(375, 374, '120802919431279', '2012-08-02 15:29:02', '9879', '9254573501052', 1, 'Anda tidak terdaftar. Reg BONUS ke 9879 untuk mendaftar', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120802919431279</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(376, 0, '120802613741277', '2012-08-02 15:17:05', '9879', '9254573501052', 1, 'reg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(377, 376, '120802613741277', '2012-08-02 15:30:02', '9879', '9254573501052', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120802613741277</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(378, 0, '120802613741277', '2012-08-02 15:30:02', '9879', '9254573501052', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120802891629307</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(379, 0, '201208021700021343901602015', '2012-08-02 17:01:04', '9879', '9254570601385', 1, 'Allah Azza Wajalla merahasiakan dosa hambanya di dunia &merahasiakannya pula di akhirat. (HR. Muslim).\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120802580687712</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(380, 0, '2012080218530113439083819798', '2012-08-02 18:54:01', '9879', '9254570601385', 1, 'Allah Azza Wajalla merahasiakan dosa hambanya di dunia &merahasiakannya pula di akhirat. (HR. Muslim).\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120802816268747</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(381, 0, '2012080218530113439083819517', '2012-08-02 18:54:01', '9879', '9254570601385', 1, '2AgstDzr:12:01,Ashr:15:23,Mgb:17:56,Isya:19:09,3AgstSbh:04:45(wib),seorang isteri mnt ijin suaminya utk pergi ke masjid mk jgnlah sg suami mlrnganya. (HR. Bukha', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120802938988865</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(382, 0, '2012080307000213439520022461', '2012-08-03 07:01:05', '9879', '9254573501052', 1, 'Doa Mohon Kesabaran: Tuhan,limpahkanlah kesabaran atas kami,kukuh tetapkanlah pendirian kami dan tolonglah akan kami yg mengingkari.Klik http:/m.marimain.com/yt', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120803623124305</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(383, 0, '2012080307000213439520022096', '2012-08-03 07:01:05', '9879', '9254570601385', 1, 'ADZAN:3AgsDzr:12:01,Ashr:15:23,Mgb:17:57,Isya:19:09,4MarSbh:04:45(WIB) Allah SWT.  merahasiakan dosa hamba ddunia &merahasiakannya pL dakhirat. (HR. Muslim).\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080368450407</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(384, 0, '2012080307000213439520022221', '2012-08-03 07:01:05', '9879', '9254573501052', 1, 'ADZAN:3AgsDzr:12:01,Ashr:15:23,Mgb:17:57,Isya:19:09,4MarSbh:04:45(WIB) Allah SWT.  merahasiakan dosa hamba ddunia &merahasiakannya pL dakhirat. (HR. Muslim).\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080322744594</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(385, 0, '120803786928226', '2012-08-03 11:17:18', '9879', '9254573408913', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(386, 385, '120803786928226', '2012-08-03 11:29:01', '9879', '9254573408913', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120803786928226</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(387, 0, '120803509788382', '2012-08-03 11:41:51', '9879', '9254573501052', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(388, 387, '120803509788382', '2012-08-03 11:53:01', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120803509788382</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(389, 0, '120803747360527', '2012-08-03 11:42:35', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(390, 389, '120803747360527', '2012-08-03 11:54:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120803747360527</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(391, 0, '2012080317000213439880023509', '2012-08-03 17:01:07', '9879', '9254570601385', 1, 'Kekuatan Allah beserta jamaah (seluruh umat). Barangsiapa membelot maka dia membelot ke neraka. (HR. Tirmidzi)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120803334393734</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(392, 0, '2012080407000213440384026896', '2012-08-04 07:01:05', '9879', '9254573501052', 1, 'Ya Tuhan, janganlah Engkau jadikan kami sasaran fitnah bagi kaum yang zhalim, http://m.marimain.com/ytfree/?c=1003 \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120804767174618</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(393, 0, '2012080407000213440384026484', '2012-08-04 07:01:05', '9879', '9254573408913', 1, 'ADZAN:4AgsDzr:12:01,Ashr:15:23,Mgb:17:57,Isya:19:09,6AgsSbh:04:45(WIB),Kekuatan Allah beserta jamaah Brgsp membelot mk dia membelot knrk. (HR. Tirmidzi)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120804704252076</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(394, 0, '2012080407000213440384026448', '2012-08-04 07:01:05', '9879', '9254570601385', 1, 'ADZAN:4AgsDzr:12:01,Ashr:15:23,Mgb:17:57,Isya:19:09,6AgsSbh:04:45(WIB),Kekuatan Allah beserta jamaah Brgsp membelot mk dia membelot knrk. (HR. Tirmidzi)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120804497436022</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0);
INSERT INTO `tbl_msgtransact` (`ID`, `IN_REPLY_TO`, `MSGINDEX`, `MSGTIMESTAMP`, `ADN`, `MSISDN`, `OPERATORID`, `MSGDATA`, `MSGLASTSTATUS`, `MSGSTATUS`, `CLOSEREASON`, `SERVICEID`, `MEDIA`, `CHANNEL`, `SERVICE`, `PARTNER`, `SUBJECT`, `PRICE`, `ISR`) VALUES
(395, 0, '2012080407000213440384026711', '2012-08-04 07:01:05', '9879', '9254573501052', 1, 'ADZAN:4AgsDzr:12:01,Ashr:15:23,Mgb:17:57,Isya:19:09,6AgsSbh:04:45(WIB),Kekuatan Allah beserta jamaah Brgsp membelot mk dia membelot knrk. (HR. Tirmidzi)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080410826410</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(396, 0, '2012080507000113441248018488', '2012-08-05 07:01:05', '9879', '9254573501052', 1, 'Sebaik baiknya masjid (tempat bersujud) untk wanita ialah dlm rumahnya sendiri. (HR. Al-Baihaqi dan Asysyihaab), http://m.marimain.com/ytfree/?c=1005 \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120805410606036</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(397, 0, '2012080507000113441248018082', '2012-08-05 07:01:05', '9879', '9254573408913', 1, 'ADZAN:5Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh 6Ags:04:45 (WIB)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120805490794136</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(398, 0, '2012080507000113441248017732', '2012-08-05 07:01:05', '9879', '9254570601385', 1, 'ADZAN:5Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh 6Ags:04:45 (WIB)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120805747104411</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(399, 0, '2012080507000113441248018108', '2012-08-05 07:01:06', '9879', '9254573501052', 1, 'ADZAN:5Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh 6Ags:04:45 (WIB)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120805813527701</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(400, 0, '201208051700021344160802358', '2012-08-05 17:01:04', '9879', '9254573408913', 1, 'Rasulullah Saw melarang membunuh hewan dengan mengurungnya dan membiarkannya mati karena lapar dan haus. (HR. Muslim)\r\n\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120805640578079</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(401, 0, '2012080517000213441608023542', '2012-08-05 17:01:04', '9879', '9254570601385', 1, 'Rasulullah Saw melarang membunuh hewan dengan mengurungnya dan membiarkannya mati karena lapar dan haus. (HR. Muslim)\r\n\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120805912426831</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(402, 0, '2012080517000213441608023606', '2012-08-05 17:01:04', '9879', '9254573501052', 1, 'Rasulullah Saw melarang membunuh hewan dengan mengurungnya dan membiarkannya mati karena lapar dan haus. (HR. Muslim)\r\n\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120805639785446</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(403, 0, '2012080607000213442112025418', '2012-08-06 07:01:04', '9879', '9254573408913', 1, 'ADZAN:6Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh 7Ags:04:45 (WIB)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120806390009154</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(404, 0, '2012080607000213442112025562', '2012-08-06 07:01:04', '9879', '9254573501052', 1, 'Tiadalah kamu beriman sehingga perilaku hawa nafsumu sesuai dengan tuntunan ajaran yang aku bawa. (HR. Ath Thabrani),\r\nhttp://m.marimain.com/ytfree/?c=1006\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120806817572167</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(405, 0, '201208060700021344211202507', '2012-08-06 07:01:04', '9879', '9254570601385', 1, 'ADZAN:6Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh 7Ags:04:45 (WIB)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120806438119287</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(406, 0, '2012080607000213442112025441', '2012-08-06 07:01:04', '9879', '9254573501052', 1, 'ADZAN:6Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh 7Ags:04:45 (WIB)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120806618484986</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(407, 0, '120806375530803', '2012-08-06 12:17:23', '9879', '925455556977', 1, 'off', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(408, 0, '120806845956983', '2012-08-06 13:26:50', '9879', '9254570601385', 1, 'reg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(409, 408, '120806845956983', '2012-08-06 13:38:02', '9879', '9254570601385', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120806845956983</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(410, 0, '120806845956983', '2012-08-06 13:38:02', '9879', '9254570601385', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120806342761539</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(411, 0, '2012080617000213442472020983', '2012-08-06 17:01:06', '9879', '9254573408913', 1, 'Taqdir Allah sama sekali bukan sebagai pemaksaan, Allah lebih tahu terhadap hambanya yang pantas mendapatkan kebaikan dan yang tidak.\r\n\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120806538253686</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(412, 0, '2012080617000213442472020723', '2012-08-06 17:01:06', '9879', '9254570601385', 1, 'Taqdir Allah sama sekali bukan sebagai pemaksaan, Allah lebih tahu terhadap hambanya yang pantas mendapatkan kebaikan dan yang tidak.\r\n\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120806649496987</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(413, 0, '2012080617000213442472023295', '2012-08-06 17:01:06', '9879', '9254573501052', 1, 'Taqdir Allah sama sekali bukan sebagai pemaksaan, Allah lebih tahu terhadap hambanya yang pantas mendapatkan kebaikan dan yang tidak.\r\n\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120806171163685</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(414, 0, '120806702120399', '2012-08-06 19:34:27', '9879', '925455556977', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(415, 414, '120806702120399', '2012-08-06 19:46:02', '9879', '925455556977', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120806702120399</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(416, 0, '120806214855548', '2012-08-06 21:55:33', '9879', '9254597444299', 1, 'off', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(417, 0, '2012080707000213442976021755', '2012-08-07 07:01:05', '9879', '9254570601385', 1, 'Tiap orang yang bertakwa termasuk keluarga Muhammad (umat Muhammad). (HR. Ath Thabrani dan Al Baihaqi)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807477498081</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(418, 0, '201208070700021344297602188', '2012-08-07 07:01:05', '9879', '925455556977', 1, 'Tiap orang yang bertakwa termasuk keluarga Muhammad (umat Muhammad). (HR. Ath Thabrani dan Al Baihaqi)', 'FAILED', 'FAILED', '', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(419, 0, '2012080707000213442976021831', '2012-08-07 07:01:05', '9879', '9254573408913', 1, 'Tiap orang yang bertakwa termasuk keluarga Muhammad (umat Muhammad). (HR. Ath Thabrani dan Al Baihaqi)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807871044249</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(420, 0, '2012080707000213442976022119', '2012-08-07 07:01:05', '9879', '9254573501052', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang , apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1026', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807456915777</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(421, 0, '2012080707000213442976022144', '2012-08-07 07:01:05', '9879', '9254570601385', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang , apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1026', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807951148475</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(422, 0, '2012080707000213442976021855', '2012-08-07 07:02:01', '9879', '9254573501052', 1, 'Tiap orang yang bertakwa termasuk keluarga Muhammad (umat Muhammad). (HR. Ath Thabrani dan Al Baihaqi)', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807801393591</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(423, 0, '120807161273619', '2012-08-07 10:26:59', '9879', '9254573501052', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(424, 423, '120807161273619', '2012-08-07 10:40:02', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807161273619</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(425, 0, '120807434112520', '2012-08-07 10:29:31', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(426, 425, '120807434112520', '2012-08-07 10:43:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807434112520</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(427, 0, '120807493794860', '2012-08-07 10:38:50', '9879', '9254573501052', 1, 'adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(428, 427, '120807493794860', '2012-08-07 10:50:01', '9879', '9254573501052', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yg menjadi pegangan urusanku, \nklik disini http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807493794860</tid></message>', '9879SMSPULL1000', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 1000, 0),
(429, 0, '120807829000919', '2012-08-07 11:41:47', '9879', '9254573501052', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(430, 429, '120807829000919', '2012-08-07 11:55:02', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807829000919</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(431, 0, '120807369536062', '2012-08-07 11:43:14', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(432, 431, '120807369536062', '2012-08-07 11:56:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807369536062</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(433, 0, '120807904115783', '2012-08-07 15:38:52', '9879', '9254573501052', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(434, 433, '120807904115783', '2012-08-07 15:50:01', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807904115783</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(435, 0, '120807733274464', '2012-08-07 15:39:35', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(436, 435, '120807733274464', '2012-08-07 15:51:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807733274464</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(437, 0, '120807733274464', '2012-08-07 15:51:01', '9879', '9254573501052', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone Gratis KETIK <ADZAN> K 9879', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807603644464</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(438, 0, '120807324135090', '2012-08-07 15:38:38', '9879', '925455556977', 1, 'unreg', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(439, 0, '120807833072498', '2012-08-07 15:43:01', '9879', '925455556977', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(440, 0, '12080781506913', '2012-08-07 15:42:14', '9879', '9254573501052', 1, 'adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(441, 439, '120807833072498', '2012-08-07 15:55:01', '9879', '925455556977', 1, 'Anda masih terdaftar di layanan adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807833072498</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(442, 0, '120807833072498', '2012-08-07 15:55:01', '9879', '925455556977', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone Gratis KETIK <ADZAN> K 9879', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807110020596</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(443, 440, '12080781506913', '2012-08-07 15:55:01', '9879', '9254573501052', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yg menjadi pegangan urusanku, \nklik disini http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080781506913</tid></message>', '9879SMSPULL1000', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 1000, 0),
(444, 0, '120807644046842', '2012-08-07 15:53:26', '9879', '9254573501052', 1, 'unreg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(445, 444, '120807644046842', '2012-08-07 16:06:01', '9879', '9254573501052', 1, 'Status registrasi Anda di layanan BONUS telah kami non-aktifkan. Terima kasih atas partisipasi Anda', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807644046842</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(446, 0, '120807340267086', '2012-08-07 15:55:21', '9879', '9254573501052', 1, 'reg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(447, 446, '120807340267086', '2012-08-07 16:08:01', '9879', '9254573501052', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807340267086</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(448, 0, '120807340267086', '2012-08-07 16:08:01', '9879', '9254573501052', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807926960940</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(449, 0, '120807945018873', '2012-08-07 16:10:15', '9879', '9254573501052', 1, 'bonus', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(450, 0, '120807485202622', '2012-08-07 16:46:11', '9879', '925455556977', 1, 'adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(451, 450, '120807485202622', '2012-08-07 16:59:01', '9879', '925455556977', 1, 'ADZAN: Ya Allah, perbaikilah bagiku agamaku yg menjadi pegangan urusanku, \nklik disini http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807485202622</tid></message>', '9879SMSPULL1000', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 1000, 0),
(452, 0, '2012080717000213443336024819', '2012-08-07 17:01:05', '9879', '9254573408913', 1, 'Jauhkanlah hamba dari dosa dosa hamba yang buruk selama ini, dan panjangkanlah umur kedua Orang Tua saya.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807462797589</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(453, 0, '2012080717000213443336024968', '2012-08-07 17:01:05', '9879', '925455556977', 1, 'Jauhkanlah hamba dari dosa dosa hamba yang buruk selama ini, dan panjangkanlah umur kedua Orang Tua saya.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807382998952</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(454, 0, '2012080717000213443336024796', '2012-08-07 17:01:05', '9879', '9254570601385', 1, 'Jauhkanlah hamba dari dosa dosa hamba yang buruk selama ini, dan panjangkanlah umur kedua Orang Tua saya.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120807171990725</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(455, 0, '2012080807000213443840024437', '2012-08-08 07:01:05', '9879', '9254570601385', 1, 'Maha Suci (Allah) yang di tangan-Nya kekuasaan atas segala sesuatu dan kepada-Nya lah kamu dikembalikan (YASSIN AYAT 83)http://m.marimain.com/ytfree/?c=1025\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120808681270145</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(456, 0, '2012080807000213443840024462', '2012-08-08 07:01:05', '9879', '9254573501052', 1, 'Maha Suci (Allah) yang di tangan-Nya kekuasaan atas segala sesuatu dan kepada-Nya lah kamu dikembalikan (YASSIN AYAT 83)http://m.marimain.com/ytfree/?c=1025\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120808447384892</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(457, 0, '120808114552665', '2012-08-08 14:49:01', '9879', '9254573408913', 1, 'reg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(458, 457, '120808114552665', '2012-08-08 15:01:04', '9879', '9254573408913', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120808114552665</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(459, 0, '120808114552665', '2012-08-08 15:01:04', '9879', '9254573408913', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120808510545994</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(460, 0, '120808525289250', '2012-08-08 14:49:27', '9879', '9254573408913', 1, 'unreg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(461, 460, '120808525289250', '2012-08-08 15:03:01', '9879', '9254573408913', 1, 'Status registrasi Anda di layanan BONUS telah kami non-aktifkan. Terima kasih atas partisipasi Anda', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120808525289250</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(462, 0, '120808164303596', '2012-08-08 15:55:54', '9879', '9254508888515', 1, 'reg adzanwap', NULL, 'DELIVERED', '', '', '', 'wap', 'ERROR', '', 'MO;PULL;WAP;ERROR', 0, 0),
(463, 0, '2012080817000213444200020446', '2012-08-08 17:01:04', '9879', '9254570601385', 1, 'Sesungguhnya telah pasti berlaku perkataan (ketentuan Allah) terhadap kebanyakan mereka, karena mereka tidak beriman ( YASSIIN AYAT 7).\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120808779576609</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(464, 0, '2012080817000213444200020586', '2012-08-08 17:01:04', '9879', '925455556977', 1, 'Sesungguhnya telah pasti berlaku perkataan (ketentuan Allah) terhadap kebanyakan mereka, karena mereka tidak beriman ( YASSIIN AYAT 7).\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120808637624135</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(465, 0, '2012080817000213444200020555', '2012-08-08 17:01:04', '9879', '9254573408913', 1, 'Sesungguhnya telah pasti berlaku perkataan (ketentuan Allah) terhadap kebanyakan mereka, karena mereka tidak beriman ( YASSIIN AYAT 7).\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120808683616638</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(466, 0, '2012080817000213444200020624', '2012-08-08 17:01:04', '9879', '9254573501052', 1, 'Sesungguhnya telah pasti berlaku perkataan (ketentuan Allah) terhadap kebanyakan mereka, karena mereka tidak beriman ( YASSIIN AYAT 7).\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120808661318433</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(467, 0, '2012080907000313444704033249', '2012-08-09 07:01:06', '9879', '9254570601385', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang ,apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1027', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809941662118</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(468, 0, '2012080907000313444704033315', '2012-08-09 07:01:06', '9879', '9254573501052', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang ,apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1027', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809517381796</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(469, 0, '201208090700031344470403304', '2012-08-09 11:22:02', '9879', '925455556977', 1, 'ADZAN:9Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh10Ags:04:45 (WIB),Mau Ringtone Adzan Ketik Adzan k 9879 ', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>1208093975584</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(470, 0, '2012080907000313444704032832', '2012-08-09 11:22:02', '9879', '9254573408913', 1, 'ADZAN:9Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh10Ags:04:45 (WIB),Mau Ringtone Adzan Ketik Adzan k 9879 ', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809870187121</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(471, 0, '2012080907000313444704032775', '2012-08-09 11:22:02', '9879', '9254570601385', 1, 'ADZAN:9Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh10Ags:04:45 (WIB),Mau Ringtone Adzan Ketik Adzan k 9879 ', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809638322431</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(472, 0, '2012080907000313444704033065', '2012-08-09 11:22:02', '9879', '9254573501052', 1, 'ADZAN:9Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh10Ags:04:45 (WIB),Mau Ringtone Adzan Ketik Adzan k 9879 ', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809128442388</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(473, 0, '120809102448429', '2012-08-09 09:26:39', '9879', '9254573501052', 1, 'reg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(474, 0, '12080958662161', '2012-08-09 09:27:46', '9879', '9254573501052', 1, 'reg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTADUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(475, 473, '120809102448429', '2012-08-09 11:45:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809102448429</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(476, 0, '120809654501282', '2012-08-09 11:07:28', '9879', '9254508888515', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(477, 0, '120809102448429', '2012-08-09 11:45:01', '9879', '9254573501052', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809600303086</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTADWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(478, 474, '12080958662161', '2012-08-09 11:45:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080958662161</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTADUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(479, 0, '12080958662161', '2012-08-09 11:45:01', '9879', '9254573501052', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809904940566</tid></message>', '9879SMSPUSH2000', '', 'umb', 'YATTADUM', '', 'MT;PUSH;UMB;TEXT', 2000, 0),
(480, 476, '120809654501282', '2012-08-09 11:45:01', '9879', '9254508888515', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809654501282</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(481, 0, '120809654501282', '2012-08-09 11:45:01', '9879', '9254508888515', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809854781123</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(482, 0, '12080995435318', '2012-08-09 11:41:35', '9879', '9254573501052', 1, 'unreg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTADUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(483, 482, '12080995435318', '2012-08-09 11:53:02', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080995435318</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTADUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(484, 0, '120809975700488', '2012-08-09 11:44:10', '9879', '9254573501052', 1, 'unreg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(485, 484, '120809975700488', '2012-08-09 11:57:02', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809975700488</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(486, 0, '120809574559201', '2012-08-09 11:48:11', '9879', '9254573501052', 1, 'reg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(487, 0, '120809574559201', '2012-08-09 12:00:01', '9879', '9254573501052', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080953018028</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTADWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(488, 486, '120809574559201', '2012-08-09 12:00:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809574559201</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(489, 0, '120809840942226', '2012-08-09 11:49:47', '9879', '9254573501052', 1, 'unreg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(490, 489, '120809840942226', '2012-08-09 12:01:04', '9879', '9254573501052', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809840942226</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(491, 0, '120809350567642', '2012-08-09 11:55:10', '9879', '9254573501052', 1, 'reg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTADUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(492, 491, '120809350567642', '2012-08-09 12:08:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809350567642</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTADUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(493, 0, '120809350567642', '2012-08-09 12:08:01', '9879', '9254573501052', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809481390309</tid></message>', '9879SMSPUSH2000', '', 'umb', 'YATTADUM', '', 'MT;PUSH;UMB;TEXT', 2000, 0),
(494, 0, '120809170021428', '2012-08-09 12:04:52', '9879', '9254573501052', 1, 'unreg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTAZUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(495, 494, '120809170021428', '2012-08-09 12:18:02', '9879', '9254573501052', 1, 'Anda tidak terdaftar. Reg ADZAN ke 9879 untuk mendaftar', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809170021428</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTAZUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(496, 0, '120809967072116', '2012-08-09 12:05:49', '9879', '9254573501052', 1, 'reg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTAZUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(497, 0, '120809967072116', '2012-08-09 12:19:01', '9879', '9254573501052', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809462184121</tid></message>', '9879SMSPUSH2000', '', 'umb', 'YATTAZUM', '', 'MT;PUSH;UMB;TEXT', 2000, 0),
(498, 496, '120809967072116', '2012-08-09 12:19:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809967072116</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTAZUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(499, 0, '12080921975691', '2012-08-09 12:07:21', '9879', '9254573501052', 1, 'unreg', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(500, 0, '120809676065741', '2012-08-09 12:09:46', '9879', '9254573501052', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(501, 500, '120809676065741', '2012-08-09 12:21:01', '9879', '9254573501052', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809676065741</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(502, 0, '120809676065741', '2012-08-09 12:21:01', '9879', '9254573501052', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809225755822</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(503, 0, '120809230494560', '2012-08-09 12:09:15', '9879', '9254573501052', 1, 'unreg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(504, 503, '120809230494560', '2012-08-09 12:22:01', '9879', '9254573501052', 1, 'Status registrasi Anda di layanan BONUSWAP telah kami non-aktifkan. Terima kasih atas partisipasi Anda', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809230494560</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(505, 0, '120809945136601', '2012-08-09 12:11:30', '9879', '9254573501052', 1, 'reg bonusumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTBOUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(506, 505, '120809945136601', '2012-08-09 12:23:02', '9879', '9254573501052', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809945136601</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTBOUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(507, 0, '120809945136601', '2012-08-09 12:23:02', '9879', '9254573501052', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080929655750</tid></message>', '9879SMSPUSH2000', '', 'umb', 'YATTBOUM', '', 'MT;PUSH;UMB;TEXT', 2000, 0),
(508, 0, '120809234810861', '2012-08-09 12:14:40', '9879', '9254573501052', 1, 'unreg bonusumb', NULL, 'DELIVERED', '', '', '', 'umb', 'ERROR', '', 'MO;PULL;UMB;ERROR', 0, 0),
(509, 0, '120809202182745', '2012-08-09 13:51:58', '9879', '9254573501052', 1, 'reg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(510, 509, '120809202182745', '2012-08-09 14:05:01', '9879', '9254573501052', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809202182745</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(511, 0, '120809202182745', '2012-08-09 14:05:01', '9879', '9254573501052', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809473659500</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTADWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(512, 0, '120809144743793', '2012-08-09 13:55:42', '9879', '9254567224124', 1, 'off', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(513, 0, '120809737948578', '2012-08-09 14:42:59', '9879', '9254517808171', 1, 'reg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(514, 513, '120809737948578', '2012-08-09 14:55:01', '9879', '9254517808171', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809737948578</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(515, 0, '120809737948578', '2012-08-09 14:55:01', '9879', '9254517808171', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809709811860</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTADWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(516, 0, '120809509693634', '2012-08-09 14:51:50', '9879', '9254517808171', 1, 'reg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTADUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(517, 516, '120809509693634', '2012-08-09 15:05:01', '9879', '9254517808171', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809509693634</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTADUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(518, 0, '120809509693634', '2012-08-09 15:05:01', '9879', '9254517808171', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809153861260</tid></message>', '9879SMSPUSH2000', '', 'umb', 'YATTADUM', '', 'MT;PUSH;UMB;TEXT', 2000, 0),
(519, 0, '120809797201517', '2012-08-09 14:56:46', '9879', '9254517808171', 1, 'unreg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(520, 519, '120809797201517', '2012-08-09 15:08:02', '9879', '9254517808171', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809797201517</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(521, 0, '120809756709255', '2012-08-09 15:07:31', '9879', '9254517808171', 1, 'unreg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTADUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(522, 521, '120809756709255', '2012-08-09 15:21:02', '9879', '9254517808171', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809756709255</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTADUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(523, 0, '120809843665950', '2012-08-09 15:16:28', '9879', '9254517808171', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(524, 0, '120809843665950', '2012-08-09 15:28:01', '9879', '9254517808171', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809498996896</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(525, 523, '120809843665950', '2012-08-09 15:28:01', '9879', '9254517808171', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809843665950</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(526, 0, '120809368483500', '2012-08-09 15:20:33', '9879', '9254517808171', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(527, 526, '120809368483500', '2012-08-09 15:32:01', '9879', '9254517808171', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809368483500</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(528, 0, '120809614925105', '2012-08-09 15:26:36', '9879', '9254517808171', 1, 'reg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTADUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(529, 0, '120809614925105', '2012-08-09 15:38:02', '9879', '9254517808171', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809223939346</tid></message>', '9879SMSPUSH2000', '', 'umb', 'YATTADUM', '', 'MT;PUSH;UMB;TEXT', 2000, 0),
(530, 528, '120809614925105', '2012-08-09 15:38:02', '9879', '9254517808171', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809614925105</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTADUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(531, 0, '2012080915570113445026216773', '2012-08-09 15:58:01', '9879', '9254570601385', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang ,apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1027', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809897882828</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(532, 0, '201208091557011344502621689', '2012-08-09 15:58:01', '9879', '9254573501052', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang ,apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1027', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809281080527</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(533, 0, '2012080915580113445026812451', '2012-08-09 15:59:02', '9879', '9254570601385', 1, 'ADZAN:9Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh10Ags:04:45 (WIB),Mau Ringtone Adzan Ketik Adzan k 9879 ', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809526459871</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(534, 0, '2012080915580113445026812545', '2012-08-09 15:59:02', '9879', '9254573408913', 1, 'ADZAN:9Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh10Ags:04:45 (WIB),Mau Ringtone Adzan Ketik Adzan k 9879 ', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080920716670</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(535, 0, '201208091558011344502681289', '2012-08-09 15:59:02', '9879', '9254573501052', 1, 'ADZAN:9Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh10Ags:04:45 (WIB),Mau Ringtone Adzan Ketik Adzan k 9879 ', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809192203119</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(536, 0, '2012080915580113445026812697', '2012-08-09 15:59:02', '9879', '925455556977', 1, 'ADZAN:9Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh10Ags:04:45 (WIB),Mau Ringtone Adzan Ketik Adzan k 9879 ', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809240573491</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(537, 0, '120809204049665', '2012-08-09 16:20:57', '9879', '9254573501052', 1, 'reg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTADUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(538, 537, '120809204049665', '2012-08-09 16:32:02', '9879', '9254573501052', 1, 'Anda masih terdaftar di layanan adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809204049665</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTADUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(539, 0, '120809204049665', '2012-08-09 16:32:02', '9879', '9254573501052', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809789639273</tid></message>', '9879SMSPUSH2000', '', 'umb', 'YATTADUM', '', 'MT;PUSH;UMB;TEXT', 2000, 0),
(540, 0, '120809754753180', '2012-08-09 16:30:41', '9879', '9254517808171', 1, 'reg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(541, 540, '120809754753180', '2012-08-09 16:44:01', '9879', '9254517808171', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809754753180</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(542, 0, '120809754753180', '2012-08-09 16:44:01', '9879', '9254517808171', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809930133897</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(543, 0, '120809598642130', '2012-08-09 16:36:25', '9879', '9254517808171', 1, 'unreg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(544, 543, '120809598642130', '2012-08-09 16:48:01', '9879', '9254517808171', 1, 'Status registrasi Anda di layanan BONUS telah kami non-aktifkan. Terima kasih atas partisipasi Anda', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809598642130</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(545, 0, '120809500462850', '2012-08-09 16:46:53', '9879', '9254573408913', 1, 'unreg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(546, 545, '120809500462850', '2012-08-09 17:00:01', '9879', '9254573408913', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809500462850</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(547, 0, '120809395138801', '2012-08-09 16:48:58', '9879', '9254573408913', 1, 'reg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTADUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(548, 547, '120809395138801', '2012-08-09 17:01:05', '9879', '9254573408913', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809395138801</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTADUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(549, 0, '120809395138801', '2012-08-09 17:01:05', '9879', '9254573408913', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809991739042</tid></message>', '9879SMSPUSH2000', '', 'umb', 'YATTADUM', '', 'MT;PUSH;UMB;TEXT', 2000, 0),
(550, 0, '2012080917000113445064012713', '2012-08-09 17:01:06', '9879', '9254570601385', 1, 'Maka Maha Suci (Allah) yang di tangan-Nya kekuasaan atas segala sesuatu dan kepada-Nya lah kamu dikembalikan (YASSIN AYAT 83)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809644305466</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0);
INSERT INTO `tbl_msgtransact` (`ID`, `IN_REPLY_TO`, `MSGINDEX`, `MSGTIMESTAMP`, `ADN`, `MSISDN`, `OPERATORID`, `MSGDATA`, `MSGLASTSTATUS`, `MSGSTATUS`, `CLOSEREASON`, `SERVICEID`, `MEDIA`, `CHANNEL`, `SERVICE`, `PARTNER`, `SUBJECT`, `PRICE`, `ISR`) VALUES
(551, 0, '2012080917000113445064012849', '2012-08-09 17:01:06', '9879', '9254573408913', 1, 'Maka Maha Suci (Allah) yang di tangan-Nya kekuasaan atas segala sesuatu dan kepada-Nya lah kamu dikembalikan (YASSIN AYAT 83)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809279298963</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(552, 0, '2012080917000113445064012869', '2012-08-09 17:01:06', '9879', '925455556977', 1, 'Maka Maha Suci (Allah) yang di tangan-Nya kekuasaan atas segala sesuatu dan kepada-Nya lah kamu dikembalikan (YASSIN AYAT 83)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809502495677</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(553, 0, '2012080917000113445064012886', '2012-08-09 17:01:06', '9879', '9254573501052', 1, 'Maka Maha Suci (Allah) yang di tangan-Nya kekuasaan atas segala sesuatu dan kepada-Nya lah kamu dikembalikan (YASSIN AYAT 83)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809668087117</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(554, 0, '12080970957645', '2012-08-09 16:54:48', '9879', '9254517808171', 1, 'unreg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTADUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(555, 554, '12080970957645', '2012-08-09 17:08:01', '9879', '9254517808171', 1, 'Anda tlah berhenti dari SMS Adzan, mulai hari ini anda tidak menerima SMS dari kami lagi, terima kasih. CS:02123685396.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12080970957645</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTADUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(556, 0, '120809841487748', '2012-08-09 16:58:05', '9879', '9254517808171', 1, 'reg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTADUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(557, 0, '120809841487748', '2012-08-09 17:10:01', '9879', '9254517808171', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809989277497</tid></message>', '9879SMSPUSH2000', '', 'umb', 'YATTADUM', '', 'MT;PUSH;UMB;TEXT', 2000, 0),
(558, 556, '120809841487748', '2012-08-09 17:10:01', '9879', '9254517808171', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809841487748</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTADUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(559, 0, '120809269540797', '2012-08-09 17:15:00', '9879', '9254517808171', 1, 'unreg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTAZUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(560, 559, '120809269540797', '2012-08-09 17:28:02', '9879', '9254517808171', 1, 'Anda tidak terdaftar. Reg ADZAN ke 9879 untuk mendaftar', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809269540797</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTAZUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(561, 0, '120809161775663', '2012-08-09 17:17:31', '9879', '9254517808171', 1, 'reg adzanumb', NULL, '', '', '168SMSMO0', '', 'umb', 'YATTAZUM', '', 'MO;PULL;UMB;HANDLERCREATOR', 0, 0),
(562, 0, '120809161775663', '2012-08-09 17:31:01', '9879', '9254517808171', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809135791611</tid></message>', '9879SMSPUSH2000', '', 'umb', 'YATTAZUM', '', 'MT;PUSH;UMB;TEXT', 2000, 0),
(563, 561, '120809161775663', '2012-08-09 17:31:01', '9879', '9254517808171', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809161775663</tid></message>', '9879SMSPULL0', '', 'umb', 'YATTAZUM', '', 'MT;PULL;UMB;TEXT', 0, 0),
(564, 0, '120809193407779', '2012-08-09 21:23:34', '9879', '9254573501052', 1, 'reg adzan', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTADZA', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(565, 0, '120809193407779', '2012-08-09 21:35:02', '9879', '9254573501052', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809585379702</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(566, 564, '120809193407779', '2012-08-09 21:35:02', '9879', '9254573501052', 1, 'Anda masih terdaftar di layanan adzan', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120809193407779</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTADZA', '', 'MT;PULL;SMS;TEXT', 0, 0),
(567, 0, '2012081007000313445568030248', '2012-08-10 07:01:05', '9879', '9254573501052', 1, 'ADZAN:10Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh11Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810579053502</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(568, 0, '2012081007000313445568030484', '2012-08-10 07:01:05', '9879', '9254517808171', 1, 'ADZAN:10Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh11Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810947900472</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(569, 0, '2012081007000213445568029647', '2012-08-10 07:01:05', '9879', '925455556977', 1, 'ADZAN:10Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh11Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810138143190</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(570, 0, '2012081007000313445568030456', '2012-08-10 07:01:05', '9879', '9254573501052', 1, 'ADZAN:10Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh11Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810970614624</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(571, 0, '2012081007000213445568029495', '2012-08-10 07:01:05', '9879', '9254570601385', 1, 'ADZAN:10Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh11Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810162281273</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(572, 0, '2012081007000213445568029673', '2012-08-10 07:02:01', '9879', '9254573501052', 1, 'ADZAN:10Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh11Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810850679118</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(573, 0, '2012081007000213445568029972', '2012-08-10 07:02:01', '9879', '9254570601385', 1, 'Ya Tuhan, janganlah Engkau jadikan kami sasaran fitnah bagi kaum yang zhalim, http://m.marimain.com/ytfree/?c=1003 \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810634196978</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(574, 0, '201208100700031344556803006', '2012-08-10 07:02:01', '9879', '9254573501052', 1, 'Ya Tuhan, janganlah Engkau jadikan kami sasaran fitnah bagi kaum yang zhalim, http://m.marimain.com/ytfree/?c=1003 \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810624651784</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(575, 0, '120810766021777', '2012-08-10 14:22:23', '9879', '9254533149665', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(576, 0, '120810766021777', '2012-08-10 14:36:02', '9879', '9254533149665', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810848016888</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(577, 575, '120810766021777', '2012-08-10 14:36:02', '9879', '9254533149665', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810766021777</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(578, 0, '120810637613159', '2012-08-10 15:01:47', '9879', '9254504412485', 1, 'reg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(579, 0, '120810637613159', '2012-08-10 15:15:02', '9879', '9254504412485', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810329455941</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTADWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(580, 578, '120810637613159', '2012-08-10 15:15:02', '9879', '9254504412485', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810637613159</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(581, 0, '120810559478346', '2012-08-10 16:19:19', '9879', '9254504697019', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(582, 0, '120810559478346', '2012-08-10 16:32:02', '9879', '9254504697019', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810572707484</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(583, 581, '120810559478346', '2012-08-10 16:32:02', '9879', '9254504697019', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810559478346</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(584, 0, '120810738818465', '2012-08-10 16:20:32', '9879', '9254500375318', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(585, 584, '120810738818465', '2012-08-10 16:34:01', '9879', '9254500375318', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810738818465</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(586, 0, '120810738818465', '2012-08-10 16:34:01', '9879', '9254500375318', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810830730286</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(587, 0, '120810357572308', '2012-08-10 16:34:12', '9879', '9254590490782', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(588, 0, '120810357572308', '2012-08-10 16:47:01', '9879', '9254590490782', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810882156933</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(589, 587, '120810357572308', '2012-08-10 16:47:01', '9879', '9254590490782', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810357572308</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(590, 0, '2012081017000313445928031581', '2012-08-10 17:01:04', '9879', '9254573501052', 1, 'Ya Allah hanya padaMu hamba meminta Ampunan Darimu ya Allah \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810560061930</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(591, 0, '2012081017000313445928031168', '2012-08-10 17:01:04', '9879', '925455556977', 1, 'Ya Allah hanya padaMu hamba meminta Ampunan Darimu ya Allah \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810160576879</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(592, 0, '20120810170003134459280319', '2012-08-10 17:01:04', '9879', '9254517808171', 1, 'Ya Allah hanya padaMu hamba meminta Ampunan Darimu ya Allah \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810820769083</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(593, 0, '2012081017000313445928031132', '2012-08-10 17:01:04', '9879', '9254570601385', 1, 'Ya Allah hanya padaMu hamba meminta Ampunan Darimu ya Allah \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810803874297</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(594, 0, '201208101700031344592803176', '2012-08-10 17:01:04', '9879', '9254573501052', 1, 'Ya Allah hanya padaMu hamba meminta Ampunan Darimu ya Allah \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081014810692</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(595, 0, '2012081017000313445928031401', '2012-08-10 17:02:01', '9879', '9254573501052', 1, 'Ya Allah hanya padaMu hamba meminta Ampunan Darimu ya Allah \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810580175000</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(596, 0, '120810131854905', '2012-08-10 17:14:10', '9879', '9254539505515', 1, 'reg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(597, 596, '120810131854905', '2012-08-10 17:27:01', '9879', '9254539505515', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810131854905</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(598, 0, '120810131854905', '2012-08-10 17:27:01', '9879', '9254539505515', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810639389113</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTADWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(599, 0, '120810416702364', '2012-08-10 17:23:29', '9879', '9254538756100', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(600, 599, '120810416702364', '2012-08-10 17:37:02', '9879', '9254538756100', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810416702364</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(601, 0, '120810416702364', '2012-08-10 17:37:02', '9879', '9254538756100', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081014951082</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(602, 0, '120810344862823', '2012-08-10 20:51:17', '9879', '9254527532980', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(603, 602, '120810344862823', '2012-08-10 21:04:02', '9879', '9254527532980', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810344862823</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(604, 0, '120810344862823', '2012-08-10 21:04:02', '9879', '9254527532980', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810434006895</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(605, 0, '120810512367706', '2012-08-10 21:05:13', '9879', '9254577634131', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(606, 0, '120810512367706', '2012-08-10 21:18:01', '9879', '9254577634131', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810419791414</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(607, 605, '120810512367706', '2012-08-10 21:18:01', '9879', '9254577634131', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810512367706</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(608, 0, '120810196664096', '2012-08-10 22:54:28', '9879', '9254504571278', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(609, 608, '120810196664096', '2012-08-10 23:08:02', '9879', '9254504571278', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810196664096</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(610, 0, '120810196664096', '2012-08-10 23:08:02', '9879', '9254504571278', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120810566708568</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(611, 0, '120811369998712', '2012-08-11 00:48:46', '9879', '9254031971602', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(612, 611, '120811369998712', '2012-08-11 01:02:02', '9879', '9254031971602', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811369998712</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(613, 0, '120811369998712', '2012-08-11 01:02:02', '9879', '9254031971602', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811776737535</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(614, 0, '120811918247918', '2012-08-11 03:31:32', '9879', '9254537090415', 1, 'reg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(615, 614, '120811918247918', '2012-08-11 03:45:02', '9879', '9254537090415', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811918247918</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(616, 0, '120811918247918', '2012-08-11 03:45:02', '9879', '9254537090415', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811669854092</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTADWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(617, 0, '120811780216908', '2012-08-11 03:40:46', '9879', '9254537090415', 1, 'unreg', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(618, 0, '2012081107000213446432023777', '2012-08-11 07:01:06', '9879', '9254517808171', 1, 'ADZAN:11Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh12Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811423103489</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(619, 0, '2012081107000213446432023404', '2012-08-11 07:01:06', '9879', '9254573501052', 1, 'ADZAN:11Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh12Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811309590721</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(620, 0, '2012081107000213446432021905', '2012-08-11 07:01:06', '9879', '925455556977', 1, 'ADZAN:11Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh12Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811422803046</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(621, 0, '2012081107000213446432023753', '2012-08-11 07:01:06', '9879', '9254573501052', 1, 'ADZAN:11Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh12Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811279722473</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(622, 0, '201208110700021344643202185', '2012-08-11 07:01:06', '9879', '9254570601385', 1, 'ADZAN:11Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh12Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811630460899</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(623, 0, '2012081107000213446432023201', '2012-08-11 07:02:01', '9879', '9254570601385', 1, 'Sebaik baiknya masjid (tempat bersujud) untk wanita ialah dlm rumahnya sendiri. (HR. Al-Baihaqi dan Asysyihaab), http://m.marimain.com/ytfree/?c=1005 \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811607572716</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(624, 0, '2012081107000213446432023227', '2012-08-11 07:02:01', '9879', '9254573501052', 1, 'Sebaik baiknya masjid (tempat bersujud) untk wanita ialah dlm rumahnya sendiri. (HR. Al-Baihaqi dan Asysyihaab), http://m.marimain.com/ytfree/?c=1005 \r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811708185719</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(625, 0, '2012081107000213446432021931', '2012-08-11 07:02:01', '9879', '9254573501052', 1, 'ADZAN:11Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh12Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081135873369</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(626, 0, '2012081107000213446432023434', '2012-08-11 07:03:01', '9879', '9254504412485', 1, 'ADZAN:11Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh12Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811674653735</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(627, 0, '2012081107000213446432023465', '2012-08-11 07:03:01', '9879', '9254539505515', 1, 'ADZAN:11Ags Dzr:12:01,Ashr:15:23,Mgrb:17:57,Isya:19:09,Subuh12Ags:04:45 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081175800532</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(628, 0, '120811622241172', '2012-08-11 10:32:03', '9879', '9254036678642', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(629, 628, '120811622241172', '2012-08-11 10:45:01', '9879', '9254036678642', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811622241172</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(630, 0, '120811622241172', '2012-08-11 10:45:01', '9879', '9254036678642', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811701306405</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(631, 0, '1208111590405', '2012-08-11 11:43:44', '9879', '9254097965847', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(632, 631, '1208111590405', '2012-08-11 11:57:02', '9879', '9254097965847', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>1208111590405</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(633, 0, '1208111590405', '2012-08-11 11:57:02', '9879', '9254097965847', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811641349753</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(634, 0, '120811410284296', '2012-08-11 14:06:40', '9879', '9254502995305', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(635, 634, '120811410284296', '2012-08-11 14:20:01', '9879', '9254502995305', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811410284296</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(636, 0, '120811410284296', '2012-08-11 14:20:01', '9879', '9254502995305', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811699696984</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(637, 0, '201208111700021344679202845', '2012-08-11 17:01:05', '9879', '9254517808171', 1, 'Ya Allah Jauhkan kanlah kedua OrangTua kami dari api nerakaMu dan Panjangkanlah umur kedua OrangTua kami\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811526862465</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(638, 0, '2012081117000213446792028133', '2012-08-11 17:01:05', '9879', '9254573501052', 1, 'Ya Allah Jauhkan kanlah kedua OrangTua kami dari api nerakaMu dan Panjangkanlah umur kedua OrangTua kami\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811800690713</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(639, 0, '2012081117000213446792027834', '2012-08-11 17:01:05', '9879', '925455556977', 1, 'Ya Allah Jauhkan kanlah kedua OrangTua kami dari api nerakaMu dan Panjangkanlah umur kedua OrangTua kami\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811171270779</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(640, 0, '2012081117000213446792028424', '2012-08-11 17:01:05', '9879', '9254573501052', 1, 'Ya Allah Jauhkan kanlah kedua OrangTua kami dari api nerakaMu dan Panjangkanlah umur kedua OrangTua kami\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811593641939</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(641, 0, '201208111700021344679202487', '2012-08-11 17:01:05', '9879', '9254570601385', 1, 'Ya Allah Jauhkan kanlah kedua OrangTua kami dari api nerakaMu dan Panjangkanlah umur kedua OrangTua kami\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811822215910</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(642, 0, '2012081117000213446792028211', '2012-08-11 17:02:01', '9879', '9254504412485', 1, 'Ya Allah Jauhkan kanlah kedua OrangTua kami dari api nerakaMu dan Panjangkanlah umur kedua OrangTua kami\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>1208114048218</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(643, 0, '2012081117000213446792027865', '2012-08-11 17:02:01', '9879', '9254573501052', 1, 'Ya Allah Jauhkan kanlah kedua OrangTua kami dari api nerakaMu dan Panjangkanlah umur kedua OrangTua kami\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811422128436</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(644, 0, '2012081117000213446792028236', '2012-08-11 17:02:01', '9879', '9254539505515', 1, 'Ya Allah Jauhkan kanlah kedua OrangTua kami dari api nerakaMu dan Panjangkanlah umur kedua OrangTua kami\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811291501816</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(645, 0, '120811197585663', '2012-08-11 17:16:41', '9879', '925455556977', 1, 'off', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(646, 0, '120811262855843', '2012-08-11 20:18:06', '9879', '9254521211079', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(647, 0, '120811262855843', '2012-08-11 20:31:02', '9879', '9254521211079', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811278041033</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(648, 646, '120811262855843', '2012-08-11 20:31:02', '9879', '9254521211079', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811262855843</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(649, 0, '120811403161360', '2012-08-11 23:09:59', '9879', '9254504236476', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(650, 649, '120811403161360', '2012-08-11 23:23:03', '9879', '9254504236476', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811403161360</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(651, 0, '120811403161360', '2012-08-11 23:23:03', '9879', '9254504236476', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120811186998370</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(652, 0, '120812865010518', '2012-08-12 01:45:43', '9879', '9254521744990', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(653, 0, '120812865010518', '2012-08-12 01:59:01', '9879', '9254521744990', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812957078110</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(654, 652, '120812865010518', '2012-08-12 01:59:01', '9879', '9254521744990', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812865010518</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(655, 0, '120812902714823', '2012-08-12 04:33:38', '9879', '9254589318948', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(656, 0, '120812902714823', '2012-08-12 04:47:02', '9879', '9254589318948', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812256748993</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(657, 655, '120812902714823', '2012-08-12 04:47:02', '9879', '9254589318948', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812902714823</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(658, 0, '120812613495836', '2012-08-12 06:04:34', '9879', '9254509153542', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(659, 658, '120812613495836', '2012-08-12 06:18:02', '9879', '9254509153542', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812613495836</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(660, 0, '120812613495836', '2012-08-12 06:18:02', '9879', '9254509153542', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812116444304</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(661, 0, '2012081207000213447296024583', '2012-08-12 07:01:06', '9879', '9254573501052', 1, 'ADZAN:12Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh13Ags:04:44 (WIB)\r\n', 'FAILED', 'FAILED', '', '9879SMSPUSH0', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(662, 0, '201208120700021344729602461', '2012-08-12 07:01:06', '9879', '9254517808171', 1, 'ADZAN:12Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh13Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081226167182</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(663, 0, '2012081207000213447296022002', '2012-08-12 07:01:06', '9879', '9254570601385', 1, 'Tiadalah kamu beriman sehingga perilaku hawa nafsumu sesuai dengan tuntunan ajaran yang aku bawa. (HR. Ath Thabrani),\r\nhttp://m.marimain.com/ytfree/?c=1006\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812768445992</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(664, 0, '2012081207000113447296015774', '2012-08-12 07:01:06', '9879', '925455556977', 1, 'ADZAN:12Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh13Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812846373902</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(665, 0, '2012081207000213447296023978', '2012-08-12 07:01:06', '9879', '9254573501052', 1, 'ADZAN:12Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh13Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812645987036</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(666, 0, '2012081207000113447296015695', '2012-08-12 07:02:01', '9879', '9254570601385', 1, 'ADZAN:12Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh13Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812318232350</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(667, 0, '2012081207000213447296022179', '2012-08-12 07:02:01', '9879', '9254573501052', 1, 'Tiadalah kamu beriman sehingga perilaku hawa nafsumu sesuai dengan tuntunan ajaran yang aku bawa. (HR. Ath Thabrani),\r\nhttp://m.marimain.com/ytfree/?c=1006\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812925051482</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(668, 0, '2012081207000213447296023996', '2012-08-12 07:02:01', '9879', '9254504412485', 1, 'ADZAN:12Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh13Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812488276422</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(669, 0, '2012081207000113447296019385', '2012-08-12 07:03:01', '9879', '9254573501052', 1, 'ADZAN:12Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh13Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812988463786</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(670, 0, '201208120700021344729602437', '2012-08-12 07:03:01', '9879', '9254539505515', 1, 'ADZAN:12Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh13Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812126718802</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(671, 0, '2012081207000213447296024469', '2012-08-12 07:03:01', '9879', '9254537090415', 1, 'ADZAN:12Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh13Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812861047475</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(672, 0, '12081265050060', '2012-08-12 08:43:19', '9879', '9254521248377', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(673, 672, '12081265050060', '2012-08-12 08:56:02', '9879', '9254521248377', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081265050060</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(674, 0, '12081265050060', '2012-08-12 08:56:02', '9879', '9254521248377', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812130185470</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(675, 0, '120812808383848', '2012-08-12 10:48:05', '9879', '9254571249321', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(676, 0, '120812808383848', '2012-08-12 11:01:03', '9879', '9254571249321', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812131020618</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(677, 675, '120812808383848', '2012-08-12 11:01:03', '9879', '9254571249321', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812808383848</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(678, 0, '120812205413632', '2012-08-12 13:16:22', '9879', '9254538343381', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(679, 678, '120812205413632', '2012-08-12 13:30:01', '9879', '9254538343381', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812205413632</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(680, 0, '120812205413632', '2012-08-12 13:30:01', '9879', '9254538343381', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812666635643</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(681, 0, '120812382831684', '2012-08-12 14:42:30', '9879', '9254534994375', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(682, 0, '120812382831684', '2012-08-12 14:56:02', '9879', '9254534994375', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812311148882</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(683, 681, '120812382831684', '2012-08-12 14:56:02', '9879', '9254534994375', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812382831684</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(684, 0, '120812454230712', '2012-08-12 15:52:16', '9879', '9254575321908', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(685, 684, '120812454230712', '2012-08-12 16:05:02', '9879', '9254575321908', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812454230712</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(686, 0, '120812454230712', '2012-08-12 16:05:02', '9879', '9254575321908', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812738746961</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(687, 0, '2012081217000213447656021769', '2012-08-12 17:01:04', '9879', '9254573501052', 1, 'Ya Tuhan kami, berikanlah rahmat kepada kami dari sisi-Mu dan sempurnakanlah bagi kami petunjuk yang lurus dalam urusan kami ini.(QS. Al-Kahfi: 10)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812354143436</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(688, 0, '2012081217000213447656021791', '2012-08-12 17:01:04', '9879', '9254517808171', 1, 'Ya Tuhan kami, berikanlah rahmat kepada kami dari sisi-Mu dan sempurnakanlah bagi kami petunjuk yang lurus dalam urusan kami ini.(QS. Al-Kahfi: 10)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812286974871</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(689, 0, '2012081217000213447656021524', '2012-08-12 17:01:04', '9879', '9254573501052', 1, 'Ya Tuhan kami, berikanlah rahmat kepada kami dari sisi-Mu dan sempurnakanlah bagi kami petunjuk yang lurus dalam urusan kami ini.(QS. Al-Kahfi: 10)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081253705636</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(690, 0, '2012081217000113447656018263', '2012-08-12 17:01:04', '9879', '925455556977', 1, 'Ya Tuhan kami, berikanlah rahmat kepada kami dari sisi-Mu dan sempurnakanlah bagi kami petunjuk yang lurus dalam urusan kami ini.(QS. Al-Kahfi: 10)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812485314660</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(691, 0, '2012081217000113447656015448', '2012-08-12 17:01:04', '9879', '9254570601385', 1, 'Ya Tuhan kami, berikanlah rahmat kepada kami dari sisi-Mu dan sempurnakanlah bagi kami petunjuk yang lurus dalam urusan kami ini.(QS. Al-Kahfi: 10)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812567041403</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(692, 0, '2012081217000213447656021547', '2012-08-12 17:02:01', '9879', '9254504412485', 1, 'Ya Tuhan kami, berikanlah rahmat kepada kami dari sisi-Mu dan sempurnakanlah bagi kami petunjuk yang lurus dalam urusan kami ini.(QS. Al-Kahfi: 10)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812195473266</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(693, 0, '2012081217000113447656018384', '2012-08-12 17:02:01', '9879', '9254573501052', 1, 'Ya Tuhan kami, berikanlah rahmat kepada kami dari sisi-Mu dan sempurnakanlah bagi kami petunjuk yang lurus dalam urusan kami ini.(QS. Al-Kahfi: 10)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812446266404</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(694, 0, '2012081217000213447656021608', '2012-08-12 17:02:01', '9879', '9254539505515', 1, 'Ya Tuhan kami, berikanlah rahmat kepada kami dari sisi-Mu dan sempurnakanlah bagi kami petunjuk yang lurus dalam urusan kami ini.(QS. Al-Kahfi: 10)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812870733101</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(695, 0, '2012081217000213447656021627', '2012-08-12 17:03:01', '9879', '9254537090415', 1, 'Ya Tuhan kami, berikanlah rahmat kepada kami dari sisi-Mu dan sempurnakanlah bagi kami petunjuk yang lurus dalam urusan kami ini.(QS. Al-Kahfi: 10)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120812157561011</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(696, 0, '12081385604139', '2012-08-13 00:31:24', '9879', '9254500913144', 1, 'reg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(697, 0, '12081385604139', '2012-08-13 00:45:02', '9879', '9254500913144', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813794328567</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTADWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(698, 696, '12081385604139', '2012-08-13 00:45:02', '9879', '9254500913144', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081385604139</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(699, 0, '12081364706431', '2012-08-13 00:59:12', '9879', '9254526878543', 1, 'reg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(700, 0, '120813895633810', '2012-08-13 00:59:01', '9879', '92545039851', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0);
INSERT INTO `tbl_msgtransact` (`ID`, `IN_REPLY_TO`, `MSGINDEX`, `MSGTIMESTAMP`, `ADN`, `MSISDN`, `OPERATORID`, `MSGDATA`, `MSGLASTSTATUS`, `MSGSTATUS`, `CLOSEREASON`, `SERVICEID`, `MEDIA`, `CHANNEL`, `SERVICE`, `PARTNER`, `SUBJECT`, `PRICE`, `ISR`) VALUES
(701, 0, '120813895633810', '2012-08-13 01:12:01', '9879', '92545039851', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813307322818</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(702, 699, '12081364706431', '2012-08-13 01:12:01', '9879', '9254526878543', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081364706431</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(703, 700, '120813895633810', '2012-08-13 01:12:01', '9879', '92545039851', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813895633810</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(704, 0, '12081364706431', '2012-08-13 01:12:01', '9879', '9254526878543', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813515066365</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTADWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(705, 0, '120813110464080', '2012-08-13 01:29:05', '9879', '9254538669341', 1, 'reg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(706, 705, '120813110464080', '2012-08-13 01:42:01', '9879', '9254538669341', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813110464080</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(707, 0, '120813110464080', '2012-08-13 01:42:01', '9879', '9254538669341', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813992703147</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(708, 0, '120813563634622', '2012-08-13 01:32:26', '9879', '9254533411159', 1, 'reg bonus', NULL, '', '', '168SMSMO0', '', 'sms', 'YATTBONU', '', 'MO;PULL;SMS;HANDLERCREATOR', 0, 0),
(709, 708, '120813563634622', '2012-08-13 01:44:01', '9879', '9254533411159', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813563634622</tid></message>', '9879SMSPULL0', '', 'sms', 'YATTBONU', '', 'MT;PULL;SMS;TEXT', 0, 0),
(710, 0, '120813563634622', '2012-08-13 01:44:01', '9879', '9254533411159', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813956115968</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;TEXT', 2000, 0),
(711, 0, '120813872165890', '2012-08-13 01:34:50', '9879', '9254533411159', 1, 'unreg', NULL, 'DELIVERED', '', '', '', 'sms', 'ERROR', '', 'MO;PULL;SMS;ERROR', 0, 0),
(712, 0, '120813324601536', '2012-08-13 02:00:42', '9879', '9254520392140', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(713, 0, '120813324601536', '2012-08-13 02:14:02', '9879', '9254520392140', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813996269592</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(714, 712, '120813324601536', '2012-08-13 02:14:02', '9879', '9254520392140', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813324601536</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(715, 0, '120813670235264', '2012-08-13 04:10:59', '9879', '9254580297861', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(716, 715, '120813670235264', '2012-08-13 04:24:02', '9879', '9254580297861', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813670235264</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(717, 0, '120813670235264', '2012-08-13 04:24:02', '9879', '9254580297861', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813930770913</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(718, 0, '2012081307000213448160025402', '2012-08-13 07:01:06', '9879', '9254517808171', 1, 'ADZAN:13Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh14Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813860972044</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(719, 0, '2012081307000213448160025371', '2012-08-13 07:01:06', '9879', '9254573501052', 1, 'ADZAN:13Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh14Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081355404809</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(720, 0, '2012081307000213448160022278', '2012-08-13 07:01:06', '9879', '9254573501052', 1, 'ADZAN:13Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh14Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081396281472</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(721, 0, '2012081307000113448160019087', '2012-08-13 07:01:06', '9879', '925455556977', 1, 'ADZAN:13Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh14Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813221911300</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(722, 0, '2012081307000113448160019045', '2012-08-13 07:01:06', '9879', '9254570601385', 1, 'ADZAN:13Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh14Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813740347390</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(723, 0, '2012081307000213448160020954', '2012-08-13 07:02:02', '9879', '9254570601385', 1, 'Maha Suci (Allah) yang di tangan-Nya kekuasaan atas segala sesuatu dan kepada-Nya lah kamu dikembalikan (YASSIN AYAT 83)http://m.marimain.com/ytfree/?c=1025\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813443048136</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(724, 0, '201208130700021344816002497', '2012-08-13 07:02:02', '9879', '9254504412485', 1, 'ADZAN:13Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh14Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813566227592</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(725, 0, '2012081307000213448160020978', '2012-08-13 07:02:02', '9879', '9254573501052', 1, 'Maha Suci (Allah) yang di tangan-Nya kekuasaan atas segala sesuatu dan kepada-Nya lah kamu dikembalikan (YASSIN AYAT 83)http://m.marimain.com/ytfree/?c=1025\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813213043912</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(726, 0, '2012081307000113448160019103', '2012-08-13 07:03:01', '9879', '9254573501052', 1, 'ADZAN:13Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh14Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081393399780</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(727, 0, '2012081307000213448160024998', '2012-08-13 07:03:01', '9879', '9254539505515', 1, 'ADZAN:13Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh14Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813375625368</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(728, 0, '2012081307000213448160025023', '2012-08-13 07:03:01', '9879', '9254537090415', 1, 'ADZAN:13Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh14Ags:04:44 (WIB)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813744648552</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(729, 0, '120813536980149', '2012-08-13 09:57:20', '9879', '9254574097177', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(730, 0, '120813536980149', '2012-08-13 10:11:01', '9879', '9254574097177', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813151962644</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(731, 729, '120813536980149', '2012-08-13 10:11:01', '9879', '9254574097177', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813536980149</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(732, 0, '120813669646853', '2012-08-13 10:19:07', '9879', '9254504821604', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(733, 732, '120813669646853', '2012-08-13 10:32:02', '9879', '9254504821604', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813669646853</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(734, 0, '120813669646853', '2012-08-13 10:32:02', '9879', '9254504821604', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>1208137063841</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(735, 0, '120813201049755', '2012-08-13 11:15:12', '9879', '9254565474845', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(736, 735, '120813201049755', '2012-08-13 11:28:01', '9879', '9254565474845', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813201049755</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(737, 0, '120813201049755', '2012-08-13 11:28:01', '9879', '9254565474845', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813539967818</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(738, 0, '120813550266442', '2012-08-13 14:09:05', '9879', '9254535174348', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(739, 0, '120813550266442', '2012-08-13 14:22:02', '9879', '9254535174348', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081379156540</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(740, 738, '120813550266442', '2012-08-13 14:22:02', '9879', '9254535174348', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813550266442</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(741, 0, '12081394904406', '2012-08-13 16:08:18', '9879', '9254508546470', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(742, 741, '12081394904406', '2012-08-13 16:21:02', '9879', '9254508546470', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081394904406</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(743, 0, '12081394904406', '2012-08-13 16:21:02', '9879', '9254508546470', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813735263435</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(744, 0, '120813240807407', '2012-08-13 16:36:11', '9879', '9254031856005', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(745, 744, '120813240807407', '2012-08-13 16:49:01', '9879', '9254031856005', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813240807407</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(746, 0, '120813240807407', '2012-08-13 16:49:01', '9879', '9254031856005', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>1208131502232</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(747, 0, '2012081317000113448520019214', '2012-08-13 17:01:04', '9879', '9254517808171', 1, 'Ya Tuhan, lapangkanlah dadaku, mudahkanlah segala urusanku, dan lepaskanlah kekakuan lidahku, agar mereka mengerti perkataanku. (QS. Thaha: 27)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813128429549</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(748, 0, '2012081317000113448520018644', '2012-08-13 17:01:04', '9879', '9254573501052', 1, 'Ya Tuhan, lapangkanlah dadaku, mudahkanlah segala urusanku, dan lepaskanlah kekakuan lidahku, agar mereka mengerti perkataanku. (QS. Thaha: 27)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813827383276</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(749, 0, '2012081317000113448520018419', '2012-08-13 17:01:04', '9879', '925455556977', 1, 'Ya Tuhan, lapangkanlah dadaku, mudahkanlah segala urusanku, dan lepaskanlah kekakuan lidahku, agar mereka mengerti perkataanku. (QS. Thaha: 27)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813959729714</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(750, 0, '2012081317000113448520018294', '2012-08-13 17:01:04', '9879', '9254570601385', 1, 'Ya Tuhan, lapangkanlah dadaku, mudahkanlah segala urusanku, dan lepaskanlah kekakuan lidahku, agar mereka mengerti perkataanku. (QS. Thaha: 27)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813405571932</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(751, 0, '2012081317000113448520018913', '2012-08-13 17:01:04', '9879', '9254504412485', 1, 'Ya Tuhan, lapangkanlah dadaku, mudahkanlah segala urusanku, dan lepaskanlah kekakuan lidahku, agar mereka mengerti perkataanku. (QS. Thaha: 27)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813378332747</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(752, 0, '2012081317000113448520019194', '2012-08-13 17:02:01', '9879', '9254573501052', 1, 'Ya Tuhan, lapangkanlah dadaku, mudahkanlah segala urusanku, dan lepaskanlah kekakuan lidahku, agar mereka mengerti perkataanku. (QS. Thaha: 27)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813352987029</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTAZUM', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(753, 0, '2012081317000113448520018943', '2012-08-13 17:02:01', '9879', '9254539505515', 1, 'Ya Tuhan, lapangkanlah dadaku, mudahkanlah segala urusanku, dan lepaskanlah kekakuan lidahku, agar mereka mengerti perkataanku. (QS. Thaha: 27)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081347670291</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(754, 0, '2012081317000113448520018444', '2012-08-13 17:02:01', '9879', '9254573501052', 1, 'Ya Tuhan, lapangkanlah dadaku, mudahkanlah segala urusanku, dan lepaskanlah kekakuan lidahku, agar mereka mengerti perkataanku. (QS. Thaha: 27)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081357806105</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(755, 0, '2012081317000113448520018972', '2012-08-13 17:03:02', '9879', '9254537090415', 1, 'Ya Tuhan, lapangkanlah dadaku, mudahkanlah segala urusanku, dan lepaskanlah kekakuan lidahku, agar mereka mengerti perkataanku. (QS. Thaha: 27)\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081392558428</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTADWA', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(756, 0, '120813118722797', '2012-08-13 17:43:17', '9879', '9254546963779', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(757, 0, '120813118722797', '2012-08-13 17:56:01', '9879', '9254546963779', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081335354518</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(758, 756, '120813118722797', '2012-08-13 17:56:01', '9879', '9254546963779', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813118722797</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(759, 0, '120813386046482', '2012-08-13 18:28:08', '9879', '9254564184070', 1, 'reg adzanwap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTADWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(760, 759, '120813386046482', '2012-08-13 18:41:02', '9879', '9254564184070', 1, 'Selamat datang di ADZAN,kamu dpt jdwl sholat,doa harian & Ringtone Adzan.Info. 2sms/hr.Rp.2rb/sms.Stop:UNREG ADZAN ke 9879.CS:02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813386046482</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTADWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(761, 0, '120813386046482', '2012-08-13 18:41:02', '9879', '9254564184070', 1, 'ADZAN:Cukuplah bagi orang itu disebut pembohong jika dengan setiap apa yang ia dengar( HR. Muslim )mau dpt Ringtone klik http://m.marimain.com/ytfree/?c=5814', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813142152093</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTADWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(762, 0, '120813865566066', '2012-08-13 19:05:39', '9879', '92545364191', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(763, 762, '120813865566066', '2012-08-13 19:19:03', '9879', '92545364191', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'FAILED', 'FAILED', '', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(764, 0, '120813865566066', '2012-08-13 19:19:03', '9879', '92545364191', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813107446677</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(765, 0, '120813859368426', '2012-08-13 23:21:35', '9879', '9254527451584', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(766, 765, '120813859368426', '2012-08-13 23:35:02', '9879', '9254527451584', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813859368426</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(767, 0, '120813859368426', '2012-08-13 23:35:02', '9879', '9254527451584', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813204133267</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(768, 0, '120813499593892', '2012-08-13 23:34:06', '9879', '9254502436737', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(769, 0, '120813499593892', '2012-08-13 23:47:02', '9879', '9254502436737', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813102121564</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(770, 768, '120813499593892', '2012-08-13 23:47:02', '9879', '9254502436737', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120813499593892</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(771, 0, '2012081407000313449024037612', '2012-08-14 07:01:06', '9879', '925455556977', 1, 'ADZAN:14Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh15Ags:04:44 (WIB),\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814345909052</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(772, 0, '201208140700031344902403967', '2012-08-14 07:01:06', '9879', '9254533411159', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang , apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1026', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814399181019</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(773, 0, '2012081407000313449024037562', '2012-08-14 07:01:06', '9879', '9254570601385', 1, 'ADZAN:14Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh15Ags:04:44 (WIB),\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814440450997</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(774, 0, '2012081407000313449024038274', '2012-08-14 07:01:06', '9879', '9254538669341', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang , apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1026', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081423987051</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(775, 0, '2012081407000313449024038027', '2012-08-14 07:01:06', '9879', '9254570601385', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang , apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1026', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081423893744</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(776, 0, '2012081407000313449024038254', '2012-08-14 07:01:06', '9879', '9254573501052', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang , apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1026', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814966900842</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(777, 0, '2012081407000313449024037631', '2012-08-14 07:02:01', '9879', '9254573501052', 1, 'ADZAN:14Ags Dzr:12:01,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh15Ags:04:44 (WIB),\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814803976979</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(778, 0, '120814876333294', '2012-08-14 07:55:41', '9879', '9254051646760', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(779, 0, '120814876333294', '2012-08-14 08:09:02', '9879', '9254051646760', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814960831738</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(780, 778, '120814876333294', '2012-08-14 08:09:02', '9879', '9254051646760', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814876333294</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(781, 0, '120814341137410', '2012-08-14 11:29:49', '9879', '9254536869774', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(782, 781, '120814341137410', '2012-08-14 11:43:02', '9879', '9254536869774', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'FAILED', 'FAILED', '', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(783, 0, '120814341137410', '2012-08-14 11:43:02', '9879', '9254536869774', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814953580723</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(784, 0, '120814898272398', '2012-08-14 12:02:09', '9879', '9254577090486', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(785, 0, '120814898272398', '2012-08-14 12:15:02', '9879', '9254577090486', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814656081313</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(786, 784, '120814898272398', '2012-08-14 12:15:02', '9879', '9254577090486', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814898272398</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(787, 0, '120814516314765', '2012-08-14 20:34:42', '9879', '9254508944589', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(788, 0, '120814516314765', '2012-08-14 20:48:02', '9879', '9254508944589', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814761640564</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(789, 787, '120814516314765', '2012-08-14 20:48:02', '9879', '9254508944589', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814516314765</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(790, 0, '120814360082992', '2012-08-14 20:43:19', '9879', '9254572112140', 1, 'reg bonuswap', NULL, '', '', '168SMSMO0', '', 'wap', 'YATTBOWA', '', 'MO;PULL;WAP;HANDLERCREATOR', 0, 0),
(791, 790, '120814360082992', '2012-08-14 20:57:02', '9879', '9254572112140', 1, 'Thx! Ambil konten seru utk hp kamu skrg dan kamu isa mendapatkan pulsa Ro 10rb. Rp.2200/sms, 1sms/hari.Stop: UNREG BONUS ke9879.CS: 02123685396', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814360082992</tid></message>', '9879SMSPULL0', '', 'wap', 'YATTBOWA', '', 'MT;PULL;WAP;TEXT', 0, 0),
(792, 0, '120814360082992', '2012-08-14 20:57:02', '9879', '9254572112140', 1, 'Iman terbagi dua, separuh dalam sabar dan separuh dalam syukur.Klik http:/m.marimain.com /f/123456  untuk download bonus konten kamu.', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120814291654127</tid></message>', '9879SMSPUSH2000', '', 'wap', 'YATTBOWA', '', 'MT;PUSH;WAP;TEXT', 2000, 0),
(793, 0, '201208150700031344988803168', '2012-08-15 07:01:05', '9879', '925455556977', 1, 'ADZAN:15Ags Dzr:12:00,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh16Ags:04:44 (WIB),\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120815992428302</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(794, 0, '2012081507000313449888032629', '2012-08-15 07:01:05', '9879', '9254533411159', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang ,apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1027', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120815900251597</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(795, 0, '2012081507000313449888031593', '2012-08-15 07:01:05', '9879', '9254570601385', 1, 'ADZAN:15Ags Dzr:12:00,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh16Ags:04:44 (WIB),\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120815554139092</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(796, 0, '2012081507000313449888032601', '2012-08-15 07:01:05', '9879', '9254538669341', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang ,apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1027', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>12081569630806</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(797, 0, '2012081507000313449888032014', '2012-08-15 07:01:05', '9879', '9254570601385', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang ,apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1027', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120815972145630</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0),
(798, 0, '2012081507000313449888031764', '2012-08-15 07:01:05', '9879', '9254573501052', 1, 'ADZAN:15Ags Dzr:12:00,Ashr:15:22,Mgrb:17:57,Isya:19:09,Subuh16Ags:04:44 (WIB),\r\n', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120815342826875</tid></message>', '9879SMSPUSH0', '', 'sms', 'YATTADZA', '', 'MT;PUSH;SMS;DAILYPUSH', 0, 0),
(799, 0, '201208150700031344988803204', '2012-08-15 07:02:01', '9879', '9254573501052', 1, 'Apakah apabila kami telah mati&tlh menjadi tnh serta menjadi tulang ,apakah benar2 kami akn dibangkitkan (kmbali) \r\nhttp://m.marimain.com/ytfree/?c=1027', 'DELIVERED', 'DELIVERED', '<message><status>0</status><tid>120815793811035</tid></message>', '9879SMSPUSH2000', '', 'sms', 'YATTBONU', '', 'MT;PUSH;SMS;DAILYPUSH', 2000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL,
  `user_level` varchar(50) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `fullname`, `email`, `username`, `password`, `user_level`) VALUES
(1, 'administrator', '', 'admin', '5d41402abc4b2a76b9719d911017c592', 'administrator');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `charging`
--
ALTER TABLE `charging`
  ADD CONSTRAINT `charging_ibfk_1` FOREIGN KEY (`operator`) REFERENCES `operator` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `mechanism`
--
ALTER TABLE `mechanism`
  ADD CONSTRAINT `mechanism_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `mechanism_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `reply`
--
ALTER TABLE `reply`
  ADD CONSTRAINT `reply_ibfk_1` FOREIGN KEY (`mechanism_id`) REFERENCES `mechanism` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `reply_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `module` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `reply_ibfk_3` FOREIGN KEY (`charging_id`) REFERENCES `charging` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `service_charging_mapping`
--
ALTER TABLE `service_charging_mapping`
  ADD CONSTRAINT `service_charging_mapping_ibfk_3` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `service_charging_mapping_ibfk_4` FOREIGN KEY (`charging_id`) REFERENCES `charging` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
